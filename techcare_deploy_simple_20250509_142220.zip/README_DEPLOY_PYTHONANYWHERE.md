# Guia de Implantação no PythonAnywhere

Este documento contém instruções passo a passo para implantar o TechCare em uma conta gratuita do PythonAnywhere.

## Pré-requisitos

- Uma conta PythonAnywhere (você pode criar uma gratuita em [pythonanywhere.com](https://www.pythonanywhere.com))
- Os arquivos do projeto TechCare

## Ferramentas de Deploy Disponíveis

Para facilitar o processo de deploy, o TechCare inclui diversos scripts úteis:

- `check_deploy_readiness.py` - Verifica se o projeto está pronto para deploy
- `create_deploy_package.py` - Cria um pacote ZIP completo para deploy
- `create_deploy_package_simple.py` - Versão simplificada do script de pacote
- `upload_to_pythonanywhere.py` - Upload automatizado para o PythonAnywhere
- `create_admin_pythonanywhere.py` - Criação de usuário administrador após deploy
- `techcare_pythonanywhere_guide.md` - Guia rápido de referência

## Método 1: Deploy Automatizado (Recomendado)

Para facilitar o processo de deploy, criamos um script que automatiza a maioria das etapas.

### Requisitos para o método automatizado
- Token de API do PythonAnywhere (obtenha em Account > API Token)
- O módulo `requests` instalado (`pip install requests`)

### Passos para deploy automatizado

1. Execute o script `check_deploy_readiness.py` para verificar a compatibilidade:
   ```bash
   python check_deploy_readiness.py
   ```

2. Crie um pacote de deploy usando um dos seguintes scripts:
   ```bash
   # Versão completa (com verificações)
   python create_deploy_package.py
   
   # Versão simplificada (mais rápida)
   python create_deploy_package_simple.py
   ```

3. Use o script de upload automático:
   ```bash
   python upload_to_pythonanywhere.py --username SEU_USUARIO --token SEU_TOKEN_API
   ```

O script irá:
- Criar um arquivo ZIP com o código do projeto
- Fazer upload para o PythonAnywhere
- Descompactar o arquivo no servidor
- Configurar o ambiente virtual e instalar dependências
- Atualizar a configuração WSGI (se uma aplicação web já existir)
- Recarregar a aplicação

Se o script não conseguir configurar a aplicação web automaticamente, siga os passos 6 a 8 do Método 2 (Manual) abaixo.

4. Após o deploy, crie um usuário administrador:
   ```bash
   # No console do PythonAnywhere
   cd ~/TechCare
   source venv/bin/activate
   python create_admin_pythonanywhere.py
   ```

## Método 2: Deploy Manual

Se preferir fazer o deploy manualmente ou se o método automatizado falhar, siga estas etapas:

## Etapa 1: Preparar os arquivos para upload

Antes de fazer o upload para o PythonAnywhere, verifique se o projeto está pronto:

```bash
python check_deploy_readiness.py
```

Este script irá:
- Verificar se sua versão do Python é compatível
- Verificar a presença de arquivos críticos para o deploy
- Verificar dependências específicas do Windows (incompatíveis)
- Verificar adaptações para Linux
- Verificar a configuração do banco de dados
- Executar testes automatizados

## Etapa 2: Criar pacote de deploy

Crie um pacote de deploy usando um dos scripts disponíveis:

```bash
# Versão completa (com verificações)
python create_deploy_package.py

# Versão simplificada (mais rápida)
python create_deploy_package_simple.py
```

## Etapa 3: Fazer login no PythonAnywhere e criar um aplicativo web

1. Acesse [pythonanywhere.com](https://www.pythonanywhere.com) e faça login na sua conta
2. No dashboard, clique na guia "Web"
3. Clique no botão "Add a new web app"
4. Na janela que aparece, clique em "Next"
5. Selecione "Flask" como framework
6. Selecione a versão mais recente do Python (3.8 ou superior)
7. Na etapa "Select a Python version", escolha Python 3.8 ou superior
8. Na configuração do caminho, use o padrão `/home/<seu_username>/mysite/`
9. Clique em "Next" para concluir

## Etapa 4: Fazer upload dos arquivos do projeto

### Usando arquivos compactados (método mais fácil)

1. No PythonAnywhere, clique na guia "Files"
2. Navegue até `/home/<seu_username>/`
3. Crie uma pasta para o projeto:
   ```
   mkdir TechCare
   ```
4. Navegue até a pasta e clique em "Upload a file"
5. Selecione o arquivo ZIP criado e faça o upload
6. Descompacte o arquivo:
   ```bash
   cd /home/<seu_username>/
   unzip techcare_deploy_package_*.zip -d TechCare
   cd TechCare
   ```

### Usando Git (alternativa)

Se você estiver usando Git, pode clonar o repositório diretamente:

1. No PythonAnywhere, clique na guia "Consoles" e inicie um novo console Bash
2. Clone seu repositório:
   ```bash
   cd /home/<seu_username>/
   git clone <url_do_seu_repositorio> TechCare
   cd TechCare
   ```

## Etapa 5: Configurar o ambiente virtual e instalar dependências

1. No PythonAnywhere, clique na guia "Consoles" e inicie um novo console Bash
2. Crie um ambiente virtual:
   ```bash
   cd /home/<seu_username>/TechCare
   python3 -m venv venv
   source venv/bin/activate
   ```
3. Instale as dependências:
   ```bash
   pip install -r requirements_pythonanywhere.txt
   ```

## Etapa 6: Configurar o arquivo WSGI

1. No PythonAnywhere, clique na guia "Web"
2. Role para baixo até a seção "Code" e clique no link do arquivo WSGI (algo como `/var/www/<seu_username>_pythonanywhere_com_wsgi.py`)
3. Substitua todo o conteúdo do arquivo pelo seguinte:

```python
import sys
import os

# Adiciona o diretório da aplicação ao PATH
path = '/home/<seu_username>/TechCare'
if path not in sys.path:
    sys.path.append(path)

# Importa e cria a aplicação
from app import create_app

# Cria a aplicação usando as configurações de produção
application = create_app('production')
```

4. Salve o arquivo clicando em "Save"

## Etapa 7: Configurar o caminho para o aplicativo web

1. No PythonAnywhere, clique na guia "Web"
2. Role para baixo até a seção "Code" e edite as configurações:
   - **Source code**: `/home/<seu_username>/TechCare`
   - **Working directory**: `/home/<seu_username>/TechCare`
3. Na seção "Virtualenv", insira o caminho para o ambiente virtual:
   `/home/<seu_username>/TechCare/venv`

## Etapa 8: Configurar os arquivos estáticos (opcional, mas recomendado)

1. No PythonAnywhere, clique na guia "Web"
2. Role para baixo até a seção "Static files"
3. Adicione as seguintes entradas:
   - URL: `/static/` → Directory: `/home/<seu_username>/TechCare/app/static`

## Etapa 9: Reiniciar o aplicativo web

1. No PythonAnywhere, clique na guia "Web"
2. Clique no botão "Reload" para reiniciar o aplicativo web

## Etapa 10: Criar um usuário administrador

Após o deploy, é necessário criar um usuário administrador para acessar o sistema:

```bash
cd /home/<seu_username>/TechCare
source venv/bin/activate
python create_admin_pythonanywhere.py
```

Siga as instruções na tela para criar um usuário administrador.

## Etapa 11: Acessar seu aplicativo

Seu aplicativo agora está acessível através do URL `https://<seu_username>.pythonanywhere.com`

## Solução de Problemas

### Problemas com dependências específicas do Windows

Se você encontrar erros relacionados a módulos Windows (como `pywin32` ou `wmi`), verifique:

1. Abra o arquivo `app/services/diagnostic_service.py` e procure por importações específicas do Windows
2. Modifique o código para usar alternativas compatíveis com Linux ou implementar verificações de ambiente:

```python
import platform

if platform.system() == 'Windows':
    import wmi  # Apenas importa no Windows
else:
    # Use alternativas como psutil para sistemas Linux
    import psutil
```

### Erros de permissão de arquivos

Se você encontrar erros de permissão ao tentar escrever arquivos:

1. Verifique se os diretórios de dados estão sendo criados corretamente:
   ```bash
   mkdir -p /home/<seu_username>/TechCare/data/diagnostics
   mkdir -p /home/<seu_username>/TechCare/data/repair_logs
   mkdir -p /home/<seu_username>/TechCare/data/diagnostics_storage
   ```

2. Defina permissões corretas:
   ```bash
   chmod -R 755 /home/<seu_username>/TechCare/data
   ```

### Erros no log do aplicativo web

1. No PythonAnywhere, clique na guia "Web"
2. Role para baixo até a seção "Logs"
3. Clique em "Error log" para ver os erros do aplicativo

## Manutenção e Atualizações

Para atualizar o aplicativo no futuro:

1. Faça upload dos novos arquivos ou use `git pull` se estiver usando Git
2. Instale quaisquer novas dependências:
   ```bash
   pip install -r requirements_pythonanywhere.txt
   ```
3. Clique em "Reload" na guia "Web" para reiniciar o aplicativo

## Limitações da Conta Gratuita

A conta gratuita do PythonAnywhere tem algumas limitações:

- Seu aplicativo fica inativo após 3 meses sem uso
- Limitações de CPU e memória
- Apenas bancos de dados SQLite ou MySQL (você pode usar o banco de dados MySQL que vem com a conta)
- Acesso à internet limitado (lista de sites permitidos)

Para mais informações, consulte a [documentação do PythonAnywhere](https://help.pythonanywhere.com/)

## Referência Rápida

Para uma referência rápida dos comandos e etapas mais importantes, consulte o arquivo `techcare_pythonanywhere_guide.md`. 