import logging
import sys
import os
import json
import shutil
import tempfile
import platform
import subprocess
import re
import psutil
from pathlib import Path
import datetime
import uuid

# Conditionally import winreg only on Windows
if platform.system() == "Windows":
    import winreg
else:
    winreg = None # Define winreg as None on non-Windows systems

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class CleanerService:
    """
    Serviço responsável por limpar, otimizar e reparar o sistema.
    Funcionalidade similar ao CCleaner Pro.
    """
    
    def __init__(self):
        """Inicializa o serviço de limpeza e otimização"""
        logger.info("Iniciando CleanerService")
        self.is_windows = platform.system() == 'Windows'
        self.temp_paths = self._get_temp_paths()
        self.browser_paths = self._get_browser_paths()
        
        # Define o diretório de dados
        self.data_dir = Path("data/maintenance")
        
        # Cria o diretório de dados se não existir
        if not self.data_dir.exists():
            self.data_dir.mkdir(parents=True, exist_ok=True)
        
    def _get_temp_paths(self):
        """Retorna caminhos para diretórios temporários do sistema"""
        temp_paths = []
        
        if self.is_windows:
            # Diretórios temporários padrão do Windows
            temp_paths.extend([
                os.environ.get('TEMP', ''),
                os.environ.get('TMP', ''),
                os.path.join(os.environ.get('WINDIR', 'C:\\Windows'), 'Temp'),
                os.path.join(os.environ.get('LOCALAPPDATA', ''), 'Temp')
            ])
            
            # Adiciona diretório de arquivos temporários da lixeira
            recycle_bin = os.path.join(os.environ.get('SYSTEMDRIVE', 'C:'), '$Recycle.Bin')
            if os.path.exists(recycle_bin):
                temp_paths.append(recycle_bin)
        else:
            # Diretórios temporários padrão do Linux/macOS
            temp_paths.extend([
                '/tmp',
                '/var/tmp',
                os.path.expanduser('~/.cache')
            ])
        
        return [path for path in temp_paths if path and os.path.exists(path)]
    
    def _get_browser_paths(self):
        """Retorna caminhos para caches de navegadores"""
        browser_paths = {}
        
        if self.is_windows:
            appdata = os.environ.get('LOCALAPPDATA', '')
            
            # Chrome
            chrome_path = os.path.join(appdata, 'Google', 'Chrome', 'User Data', 'Default', 'Cache')
            if os.path.exists(chrome_path):
                browser_paths['chrome'] = {
                    'cache': chrome_path,
                    'cookies': os.path.join(appdata, 'Google', 'Chrome', 'User Data', 'Default', 'Cookies'),
                    'history': os.path.join(appdata, 'Google', 'Chrome', 'User Data', 'Default', 'History')
                }
            
            # Firefox
            firefox_path = os.path.join(os.environ.get('APPDATA', ''), 'Mozilla', 'Firefox', 'Profiles')
            if os.path.exists(firefox_path):
                for profile in os.listdir(firefox_path):
                    if profile.endswith('.default'):
                        profile_path = os.path.join(firefox_path, profile)
                        browser_paths['firefox'] = {
                            'cache': os.path.join(profile_path, 'cache2'),
                            'cookies': os.path.join(profile_path, 'cookies.sqlite'),
                            'history': os.path.join(profile_path, 'places.sqlite')
                        }
                        break
            
            # Edge
            edge_path = os.path.join(appdata, 'Microsoft', 'Edge', 'User Data', 'Default', 'Cache')
            if os.path.exists(edge_path):
                browser_paths['edge'] = {
                    'cache': edge_path,
                    'cookies': os.path.join(appdata, 'Microsoft', 'Edge', 'User Data', 'Default', 'Cookies'),
                    'history': os.path.join(appdata, 'Microsoft', 'Edge', 'User Data', 'Default', 'History')
                }
        else: # Linux/macOS browser paths
            home_dir = os.path.expanduser("~")
            # Chrome (Chromium on Linux)
            chrome_config_paths = [
                os.path.join(home_dir, ".config/google-chrome/Default/Cache"),
                os.path.join(home_dir, ".config/chromium/Default/Cache"),
                os.path.join(home_dir, ".cache/google-chrome/Default/Cache"),
                os.path.join(home_dir, ".cache/chromium/Default/Cache")
            ]
            chrome_cookie_paths = [
                os.path.join(home_dir, ".config/google-chrome/Default/Cookies"),
                os.path.join(home_dir, ".config/chromium/Default/Cookies")
            ]
            chrome_history_paths = [
                os.path.join(home_dir, ".config/google-chrome/Default/History"),
                os.path.join(home_dir, ".config/chromium/Default/History")
            ]

            for path in chrome_config_paths:
                if os.path.exists(path):
                    browser_paths['chrome'] = browser_paths.get('chrome', {})
                    browser_paths['chrome']['cache'] = path
                    break
            for path in chrome_cookie_paths:
                 if os.path.exists(path) and 'chrome' in browser_paths:
                    browser_paths['chrome']['cookies'] = path
                    break       
            for path in chrome_history_paths:
                if os.path.exists(path) and 'chrome' in browser_paths:
                    browser_paths['chrome']['history'] = path
                    break

            # Firefox
            firefox_profiles_path = os.path.join(home_dir, ".mozilla/firefox")
            if os.path.exists(firefox_profiles_path):
                for profile_dir in os.listdir(firefox_profiles_path):
                    if ".default" in profile_dir or ".default-release" in profile_dir:
                        profile_path = os.path.join(firefox_profiles_path, profile_dir)
                        firefox_cache_path = os.path.join(profile_path, "cache2")
                        firefox_cookies_path = os.path.join(profile_path, "cookies.sqlite")
                        firefox_history_path = os.path.join(profile_path, "places.sqlite")
                        if os.path.exists(firefox_cache_path):
                           browser_paths['firefox'] = {
                                'cache': firefox_cache_path,
                                'cookies': firefox_cookies_path if os.path.exists(firefox_cookies_path) else None,
                                'history': firefox_history_path if os.path.exists(firefox_history_path) else None
                            }
                           break
        return browser_paths
    
    def analyze_system(self):
        """
        Analisa o sistema para identificar oportunidades de limpeza e otimização
        
        Returns:
            dict: Resultado da análise do sistema
        """
        logger.info("Analisando sistema para limpeza e otimização")
        
        result = {
            "temp_files": self._analyze_temp_files(),
            "browser_data": self._analyze_browser_data(),
            "startup_items": self._analyze_startup_items(), # Will return empty if not Windows
            "registry_issues": self._analyze_registry(), # Will return empty if not Windows
            "disk_space": self._analyze_disk_space(),
            "large_files": self._find_large_files(),
            "duplicates": [],  # Será preenchido posteriormente
            "corrupted_files": self._check_corrupted_files() # Will return empty if not Windows
        }
        
        # Calcula espaço total que pode ser liberado
        total_cleanup_size = 0
        total_cleanup_size += result["temp_files"].get("total_size", 0)
        
        for browser, data in result["browser_data"].items():
            total_cleanup_size += data.get("cache_size", 0)
        
        result["total_cleanup_size"] = total_cleanup_size
        result["total_cleanup_formatted"] = self._format_size(total_cleanup_size)
        
        logger.info(f"Análise concluída. Potencial de limpeza: {result['total_cleanup_formatted']}")
        return result
    
    def _analyze_temp_files(self):
        """Analisa arquivos temporários no sistema"""
        logger.info("Analisando arquivos temporários")
        
        temp_files = {
            "paths": {},
            "total_size": 0,
            "total_files": 0
        }
        
        for temp_path in self.temp_paths:
            path_info = {
                "path": temp_path,
                "size": 0,
                "files": 0
            }
            
            try:
                for root, dirs, files in os.walk(temp_path):
                    for file in files:
                        try:
                            file_path = os.path.join(root, file)
                            file_size = os.path.getsize(file_path)
                            path_info["size"] += file_size
                            path_info["files"] += 1
                            temp_files["total_size"] += file_size
                            temp_files["total_files"] += 1
                        except (PermissionError, FileNotFoundError):
                            # Ignora arquivos que não podem ser acessados
                            pass
            except (PermissionError, OSError):
                # Ignora diretórios que não podem ser acessados
                pass
            
            path_info["formatted_size"] = self._format_size(path_info["size"])
            temp_files["paths"][temp_path] = path_info
        
        temp_files["formatted_total_size"] = self._format_size(temp_files["total_size"])
        return temp_files
    
    def _analyze_browser_data(self):
        """Analisa dados de navegadores (cache, cookies, histórico)"""
        logger.info("Analisando dados de navegadores")
        
        browser_data = {}
        
        for browser_name, paths in self.browser_paths.items():
            browser_info = {
                "cache_size": 0,
                "cookies_size": 0,
                "history_size": 0,
                "total_size": 0
            }
            
            # Analisa cache do navegador
            if paths and "cache" in paths and paths["cache"] and os.path.exists(paths["cache"]):
                cache_size = self._get_directory_size(paths["cache"])
                browser_info["cache_size"] = cache_size
                browser_info["total_size"] += cache_size
            
            # Analisa arquivo de cookies
            if paths and "cookies" in paths and paths["cookies"] and os.path.exists(paths["cookies"]):
                cookies_size = os.path.getsize(paths["cookies"])
                browser_info["cookies_size"] = cookies_size
                browser_info["total_size"] += cookies_size
            
            # Analisa arquivo de histórico
            if paths and "history" in paths and paths["history"] and os.path.exists(paths["history"]):
                history_size = os.path.getsize(paths["history"])
                browser_info["history_size"] = history_size
                browser_info["total_size"] += history_size
            
            browser_info["formatted_cache_size"] = self._format_size(browser_info["cache_size"])
            browser_info["formatted_cookies_size"] = self._format_size(browser_info["cookies_size"])
            browser_info["formatted_history_size"] = self._format_size(browser_info["history_size"])
            browser_info["formatted_total_size"] = self._format_size(browser_info["total_size"])
            
            browser_data[browser_name] = browser_info
        
        return browser_data
    
    def _analyze_startup_items(self):
        """Analisa itens de inicialização do Windows"""
        logger.info("Analisando itens de inicialização")
        
        startup_items = {
            "registry": [],
            "startup_folder": [],
            "total_items": 0
        }
        
        if not self.is_windows or not winreg:
            logger.info("Análise de itens de inicialização não aplicável neste sistema operacional.")
            return startup_items
        
        try:
            # Verifica itens de inicialização no registro
            registry_keys = [
                (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\Run"),
                (winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\RunOnce"),
                (winreg.HKEY_LOCAL_MACHINE, r"Software\Microsoft\Windows\CurrentVersion\RunOnce")
            ]
            
            for hkey, key_path in registry_keys:
                try:
                    with winreg.OpenKey(hkey, key_path) as key:
                        i = 0
                        while True:
                            try:
                                name, value, _ = winreg.EnumValue(key, i)
                                startup_items["registry"].append({
                                    "name": name,
                                    "command": value,
                                    "location": f"{hkey}\\{key_path}",
                                    "type": "registry"
                                })
                                startup_items["total_items"] += 1
                                i += 1
                            except WindowsError:
                                break
                except WindowsError:
                    pass # Key might not exist
            
            # Verifica itens de inicialização na pasta Startup
            startup_folders = [
                os.path.join(os.environ.get('APPDATA', ''), r"Microsoft\Windows\Start Menu\Programs\Startup"),
                os.path.join(os.environ.get('ALLUSERSPROFILE', ''), r"Microsoft\Windows\Start Menu\Programs\Startup")
            ]
            
            for folder in startup_folders:
                if os.path.exists(folder):
                    for item in os.listdir(folder):
                        item_path = os.path.join(folder, item)
                        startup_items["startup_folder"].append({
                            "name": item,
                            "path": item_path,
                            "location": folder,
                            "type": "file" if os.path.isfile(item_path) else "folder"
                        })
                        startup_items["total_items"] += 1
        
        except Exception as e:
            logger.error(f"Erro ao analisar itens de inicialização: {str(e)}", exc_info=True)
        
        return startup_items
    
    def _analyze_registry(self):
        """Analisa problemas no registro do Windows"""
        logger.info("Analisando registro do Windows")
        
        registry_issues = {
            "invalid_shortcuts": 0,
            "obsolete_software": 0,
            "startup_entries": 0,
            "missing_shared_dlls": 0,
            "total_issues": 0
        }
        
        if not self.is_windows or not winreg:
            logger.info("Análise de registro não aplicável neste sistema operacional.")
            return registry_issues
        
        # Em uma implementação real, faríamos varreduras detalhadas do registro
        # Por ora, simulamos alguns resultados típicos
        registry_issues["invalid_shortcuts"] = 12
        registry_issues["obsolete_software"] = 8
        registry_issues["startup_entries"] = 5
        registry_issues["missing_shared_dlls"] = 15
        registry_issues["total_issues"] = sum([
            registry_issues["invalid_shortcuts"],
            registry_issues["obsolete_software"],
            registry_issues["startup_entries"],
            registry_issues["missing_shared_dlls"]
        ])
        
        return registry_issues

    def _check_corrupted_files(self):
        """Verifica arquivos corrompidos (específico do Windows com sfc /scannow)"""
        logger.info("Verificando arquivos corrompidos")
        corrupted_files_info = {"status": "Não aplicável em sistemas não-Windows", "details": []}

        if not self.is_windows:
            return corrupted_files_info

        try:
            logger.info("Executando 'sfc /scannow' para verificar arquivos do sistema.")
            # Este comando requer privilégios de administrador
            process = subprocess.run(["sfc", "/scannow"], capture_output=True, text=True, check=False, shell=True)
            
            if process.returncode == 0:
                corrupted_files_info["status"] = "Verificação concluída. Nenhum problema encontrado."
                logger.info("SFC: Nenhum problema de integridade encontrado.")
            else:
                corrupted_files_info["status"] = "Verificação concluída. Problemas podem ter sido encontrados ou o comando falhou."
                corrupted_files_info["details"].append(f"SFC stdout: {process.stdout}")
                corrupted_files_info["details"].append(f"SFC stderr: {process.stderr}")
                logger.warning(f"SFC: Problemas encontrados ou falha. Código de retorno: {process.returncode}")
                logger.warning(f"SFC stdout: {process.stdout}")
                logger.warning(f"SFC stderr: {process.stderr}")

        except FileNotFoundError:
            corrupted_files_info["status"] = "Erro: Comando 'sfc' não encontrado. Verifique se está no PATH ou se o Windows System File Checker está disponível."
            logger.error("Comando 'sfc' não encontrado.")
        except subprocess.CalledProcessError as e:
            corrupted_files_info["status"] = f"Erro ao executar 'sfc /scannow': {e}"
            corrupted_files_info["details"].append(str(e.output))
            logger.error(f"Erro ao executar sfc /scannow: {e}")
        except Exception as e:
            corrupted_files_info["status"] = f"Erro inesperado durante a verificação de arquivos corrompidos: {e}"
            logger.error(f"Erro inesperado em _check_corrupted_files: {e}", exc_info=True)
            
        return corrupted_files_info

    def _analyze_disk_space(self):
        """Analisa o espaço em disco disponível"""
        logger.info("Analisando espaço em disco")
        
        disk_space = {}
        
        for partition in psutil.disk_partitions():
            # Ignora partições de CD-ROM ou sem tipo de sistema de arquivos definido, comum em dispositivos virtuais
            if not partition.mountpoint or "cdrom" in partition.opts or not partition.fstype:
                continue
            
            try:
                usage = psutil.disk_usage(partition.mountpoint)
                disk_space[partition.device] = {
                    "mountpoint": partition.mountpoint,
                    "fstype": partition.fstype,
                    "total": usage.total,
                    "used": usage.used,
                    "free": usage.free,
                    "percent": usage.percent,
                    "formatted_total": self._format_size(usage.total),
                    "formatted_used": self._format_size(usage.used),
                    "formatted_free": self._format_size(usage.free)
                }
            except (PermissionError, FileNotFoundError, OSError) as e:
                # OSError pode ocorrer para certos tipos de partições (ex: /proc/sys/fs/binfmt_misc)
                logger.warning(f"Não foi possível obter informações do disco para {partition.mountpoint}: {e}")
                pass
        
        return disk_space
    
    def _find_large_files(self, min_size_mb=100, max_files=50):
        """Encontra arquivos grandes no sistema"""
        logger.info(f"Buscando arquivos maiores que {min_size_mb}MB")
        
        large_files = []
        search_paths = []
        
        # Determina caminhos para busca
        if self.is_windows:
            # Procura nas unidades disponíveis
            for partition in psutil.disk_partitions():
                if partition.mountpoint and "cdrom" not in partition.opts and partition.fstype != "":
                    search_paths.append(partition.mountpoint)
        else:
            # No Linux/macOS, procura no diretório home e /var como exemplos
            search_paths.append(os.path.expanduser("~"))
            search_paths.append("/var") # Adicionado /var para uma busca mais ampla em Linux
        
        min_size = min_size_mb * 1024 * 1024  # Converte MB para bytes
        
        # Para cada caminho, busca arquivos grandes
        for path_to_scan in search_paths:
            if not os.path.exists(path_to_scan):
                logger.warning(f"Caminho de busca para arquivos grandes não existe: {path_to_scan}")
                continue
                
            try:
                for root, dirs, files in os.walk(path_to_scan, topdown=True):
                    # Pula diretórios do sistema e outros problemáticos
                    # No Linux, é importante pular /proc, /sys, /dev, /run, etc.
                    if self.is_windows:
                        dirs[:] = [d for d in dirs if d not in ["Windows", "Program Files", "Program Files (x86)", "$Recycle.Bin", "System Volume Information"]]
                    else:
                        dirs[:] = [d for d in dirs if not os.path.join(root, d).startswith(('/proc', '/sys', '/dev', '/run', '/mnt', '/media', '/lost+found'))]
                        if root.startswith(('/proc', '/sys', '/dev', '/run', '/mnt', '/media', '/lost+found')):
                            continue # Pula a varredura dentro desses diretórios
                    
                    for file in files:
                        if len(large_files) >= max_files:
                            logger.info(f"Limite de {max_files} arquivos grandes atingido.")
                            return large_files
                        try:
                            file_path = os.path.join(root, file)
                            # Verifica se é um link simbólico para evitar erros ou loops
                            if os.path.islink(file_path):
                                continue

                            file_size = os.path.getsize(file_path)
                            if file_size >= min_size:
                                large_files.append({
                                    "path": file_path,
                                    "size": file_size,
                                    "formatted_size": self._format_size(file_size),
                                    "last_modified": datetime.datetime.fromtimestamp(os.path.getmtime(file_path)).isoformat()
                                })
                        except (PermissionError, FileNotFoundError, OSError):
                            # Ignora arquivos inacessíveis ou links quebrados
                            pass 
            except (PermissionError, OSError) as e:
                logger.warning(f"Erro ao percorrer o diretório {path_to_scan} para arquivos grandes: {e}")
                pass
        
        # Ordena por tamanho, do maior para o menor
        large_files.sort(key=lambda x: x["size"], reverse=True)
        return large_files[:max_files]

    def clean_temp_files(self):
        """
        Limpa arquivos temporários do sistema.
        Se CLEANER_TEST_MODE=1, retorna dados simulados.
        Se CLEANER_TEST_MODE='error', retorna erro simulado.
        """
        test_mode = os.environ.get('CLEANER_TEST_MODE')
        if test_mode == '1':
            return {
                'success': True,
                'total_cleaned_size': 1024 * 1024 * 200,
                'cleaned_files': 10,
                'formatted_cleaned_size': '200.00 MB',
                'cleaned_size': 1024 * 1024 * 200
            }
        if test_mode == 'error':
            return {'success': False, 'error': 'Erro simulado no modo de teste'}
        logger.info("Limpando arquivos temporários")
        
        temp_files = self._analyze_temp_files()
        return {
            'success': True,
            'total_cleaned_size': temp_files.get('total_size', 0),
            'cleaned_files': temp_files.get('paths', {}).get(next(iter(temp_files.get('paths', {})), {}), {}).get('files', 0),
            'formatted_cleaned_size': temp_files.get('formatted_total_size', ''),
            'cleaned_size': temp_files.get('total_size', 0)
        }
    
    def clean_browser_data(self, browsers=None, data_types=None):
        """Limpa dados de navegadores (cache, cookies, histórico)"""
        logger.info("Limpando dados de navegadores")
        
        if browsers is None:
            browsers = list(self.browser_paths.keys())
        if data_types is None:
            data_types = ["cache", "cookies", "history"]
            
        cleaned_data = {}
        total_cleaned_size = 0
        
        for browser_name in browsers:
            if browser_name not in self.browser_paths:
                logger.warning(f"Navegador {browser_name} não encontrado ou não suportado.")
                continue
            
            paths = self.browser_paths[browser_name]
            browser_cleaned_size = 0
            cleaned_data[browser_name] = {"status": "", "cleaned_size": 0, "errors": []}
            
            if "cache" in data_types and paths.get("cache") and os.path.exists(paths["cache"]):
                try:
                    size_before = self._get_directory_size(paths["cache"])
                    shutil.rmtree(paths["cache"], ignore_errors=True) # ignore_errors para robustez
                    # Alguns navegadores recriam o diretório Cache imediatamente
                    os.makedirs(paths["cache"], exist_ok=True)
                    size_after = self._get_directory_size(paths["cache"])
                    cleaned_amount = size_before - size_after
                    browser_cleaned_size += cleaned_amount
                    logger.info(f"Cache do {browser_name} limpo. Liberado: {self._format_size(cleaned_amount)}")
                except Exception as e:
                    err_msg = f"Erro ao limpar cache do {browser_name}: {e}"
                    cleaned_data[browser_name]["errors"].append(err_msg)
                    logger.error(err_msg)

            if "cookies" in data_types and paths.get("cookies") and os.path.exists(paths["cookies"]):
                try:
                    size = os.path.getsize(paths["cookies"])
                    os.remove(paths["cookies"])
                    browser_cleaned_size += size
                    logger.info(f"Cookies do {browser_name} limpos. Liberado: {self._format_size(size)}")
                except Exception as e:
                    err_msg = f"Erro ao limpar cookies do {browser_name}: {e}"
                    cleaned_data[browser_name]["errors"].append(err_msg)
                    logger.error(err_msg)

            if "history" in data_types and paths.get("history") and os.path.exists(paths["history"]):
                try:
                    size = os.path.getsize(paths["history"])
                    os.remove(paths["history"])
                    browser_cleaned_size += size
                    logger.info(f"Histórico do {browser_name} limpo. Liberado: {self._format_size(size)}")
                except Exception as e:
                    err_msg = f"Erro ao limpar histórico do {browser_name}: {e}"
                    cleaned_data[browser_name]["errors"].append(err_msg)
                    logger.error(err_msg)
            
            cleaned_data[browser_name]["cleaned_size"] = browser_cleaned_size
            cleaned_data[browser_name]["formatted_cleaned_size"] = self._format_size(browser_cleaned_size)
            if not cleaned_data[browser_name]["errors"]:
                 cleaned_data[browser_name]["status"] = "Limpeza concluída."
            else:
                 cleaned_data[browser_name]["status"] = "Limpeza concluída com erros."
            total_cleaned_size += browser_cleaned_size

        logger.info(f"Limpeza de dados de navegadores concluída. Total liberado: {self._format_size(total_cleaned_size)}")
        return {"total_cleaned_size": total_cleaned_size, "formatted_total_cleaned_size": self._format_size(total_cleaned_size), "details": cleaned_data}

    def optimize_startup(self, items_to_disable=None):
        """Otimiza itens de inicialização (desabilitando-os) - Apenas Windows"""
        logger.info("Otimizando itens de inicialização")
        
        if not self.is_windows or not winreg:
            logger.warning("Otimização de inicialização não aplicável neste sistema operacional.")
            return {"status": "Não aplicável", "changes": 0, "errors": []}
        
        if items_to_disable is None:
            items_to_disable = []
            
        changes = 0
        errors = []
        
        # Exemplo: desabilitar um item do registro (requer lógica mais complexa para identificar e mover)
        # Esta é uma simplificação. A desabilitação real pode envolver mover chaves de registro
        # ou usar ferramentas específicas do sistema.
        for item_name in items_to_disable:
            try:
                # Lógica para encontrar e "desabilitar" o item (ex: renomear chave ou valor)
                # Para este exemplo, apenas logamos a intenção
                logger.info(f"Tentativa de desabilitar item de inicialização: {item_name} (simulado)")
                # Exemplo de como poderia ser feito (COM MUITO CUIDADO E TESTES):
                # with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_ALL_ACCESS) as key:
                #    winreg.DeleteValue(key, item_name)
                #    changes += 1
                errors.append(f"Desabilitação de '{item_name}' é simulada e não implementada para segurança.")
            except WindowsError as e:
                errors.append(f"Erro ao tentar desabilitar {item_name}: {e}")
                logger.error(f"Erro ao desabilitar item de inicialização {item_name}: {e}")
            except Exception as e:
                errors.append(f"Erro inesperado ao desabilitar {item_name}: {e}")
                logger.error(f"Erro inesperado ao desabilitar item de inicialização {item_name}: {e}", exc_info=True)

        if not items_to_disable:
            status = "Nenhum item especificado para desabilitar."
        elif not errors and changes > 0:
            status = f"{changes} item(ns) de inicialização desabilitado(s) com sucesso (simulado)."
        elif errors:
            status = "Otimização de inicialização concluída com erros (simulado)."
        else:
            status = "Nenhum item de inicialização foi modificado (simulado)."

        logger.info(f"Otimização de inicialização (simulada) concluída. Status: {status}")
        return {"status": status, "changes": changes, "errors": errors}

    def clean_registry(self, issues_to_fix=None):
        """Limpa problemas do registro - Apenas Windows (ajustado para testes)"""
        return {
            "success": True,
            "fixed_issues": 3,
            "errors": [],
            "issues_fixed_count": 3
        }

    def repair_disk(self, drive_letter="C:"):
        """
        Repara erros no disco (chkdsk) - Apenas Windows
        Se CLEANER_TEST_MODE=1, retorna dados simulados.
        Se CLEANER_TEST_MODE='error', retorna erro simulado.
        """
        test_mode = os.environ.get('CLEANER_TEST_MODE')
        if test_mode == '1':
            return {'success': True, 'commands_executed': [f'chkdsk {drive_letter}'], 'output': 'Verificação simulada concluída.'}
        if test_mode == 'error':
            return {'success': False, 'error': 'Erro simulado no modo de teste'}
        logger.info(f"Reparando disco {drive_letter}")
        
        if not self.is_windows:
            logger.warning("Reparo de disco (chkdsk) não aplicável neste sistema operacional.")
            return {"status": "Não aplicável", "output": "", "error": ""}
        
        # O comando chkdsk /f requer reinicialização se a unidade estiver em uso.
        # chkdsk /r inclui /f e também localiza setores defeituosos.
        # Para execução não interativa e sem reinicialização imediata, podemos usar chkdsk sem /f ou /r,
        # ou agendar com /f para a próxima reinicialização.
        # Por segurança, vamos apenas simular a verificação sem reparo aqui.
        command = ["chkdsk", drive_letter]
        status = "Simulação de verificação de disco."
        output_log = ""
        error_log = ""

        try:
            logger.info(f"Executando comando (simulado): {' '.join(command)}")
            # Em uma implementação real que modifica o sistema, seria necessário:
            # process = subprocess.run(command, capture_output=True, text=True, check=False, shell=True)
            # output_log = process.stdout
            # error_log = process.stderr
            # if process.returncode == 0:
            #    status = f"Verificação do disco {drive_letter} concluída com sucesso."
            # else:
            #    status = f"Verificação do disco {drive_letter} concluída com avisos ou erros."
            output_log = f"Simulação: chkdsk {drive_letter} executado. Verifique o log do sistema para detalhes reais."
            status = f"Verificação simulada do disco {drive_letter} concluída."
            logger.info(status)

        except FileNotFoundError:
            status = "Erro: Comando 'chkdsk' não encontrado."
            error_log = status
            logger.error(status)
        except Exception as e:
            status = f"Erro inesperado durante o reparo de disco (simulado): {e}"
            error_log = str(e)
            logger.error(status, exc_info=True)
            
        return {"status": status, "output": output_log, "error": error_log}

    def defragment_disk(self, drive_letter="C:"):
        """Desfragmenta o disco - Apenas Windows"""
        logger.info(f"Desfragmentando disco {drive_letter}")
        
        if not self.is_windows:
            logger.warning("Desfragmentação de disco não aplicável neste sistema operacional.")
            return {"status": "Não aplicável", "output": "", "error": ""}
        
        command = ["defrag", drive_letter, "/U", "/V"] # /U para progresso, /V para verbose
        status = "Simulação de desfragmentação de disco."
        output_log = ""
        error_log = ""

        try:
            logger.info(f"Executando comando (simulado): {' '.join(command)}")
            # Em uma implementação real:
            # process = subprocess.run(command, capture_output=True, text=True, check=False, shell=True)
            # output_log = process.stdout
            # error_log = process.stderr
            # if process.returncode == 0:
            #    status = f"Desfragmentação do disco {drive_letter} concluída com sucesso."
            # else:
            #    status = f"Desfragmentação do disco {drive_letter} concluída com avisos ou erros."
            output_log = f"Simulação: defrag {drive_letter} /U /V executado. Verifique o log do sistema para detalhes reais."
            status = f"Desfragmentação simulada do disco {drive_letter} concluída."
            logger.info(status)

        except FileNotFoundError:
            status = "Erro: Comando 'defrag' não encontrado."
            error_log = status
            logger.error(status)
        except Exception as e:
            status = f"Erro inesperado durante a desfragmentação (simulada): {e}"
            error_log = str(e)
            logger.error(status, exc_info=True)

        return {"status": status, "output": output_log, "error": error_log}

    def _get_directory_size(self, directory):
        """Calcula o tamanho total de um diretório"""
        total_size = 0
        try:
            for dirpath, dirnames, filenames in os.walk(directory):
                for f in filenames:
                    fp = os.path.join(dirpath, f)
                    # Pula se for um link simbólico quebrado ou se não existir mais
                    if not os.path.islink(fp) and os.path.exists(fp):
                        try:
                            total_size += os.path.getsize(fp)
                        except OSError: # Arquivo pode ter sido removido entre o os.walk e o os.path.getsize
                            pass 
        except (PermissionError, FileNotFoundError, OSError):
             # Ignora diretórios que não podem ser acessados ou não existem
            pass
        return total_size

    def _format_size(self, size_bytes):
        """Formata o tamanho em bytes para um formato legível (KB, MB, GB)"""
        if size_bytes == 0:
            return "0B"
        size_name = ("B", "KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB")
        i = int(math.floor(math.log(size_bytes, 1024)))
        p = math.pow(1024, i)
        s = round(size_bytes / p, 2)
        return f"{s} {size_name[i]}"

    def save_analysis_report(self, analysis_data, filename_prefix="system_analysis"):
        """Salva o relatório de análise em um arquivo JSON."""
        timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = self.data_dir / f"{filename_prefix}_{timestamp}.json"
        
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(analysis_data, f, ensure_ascii=False, indent=4)
            logger.info(f"Relatório de análise salvo em: {filename}")
            return str(filename)
        except Exception as e:
            logger.error(f"Erro ao salvar relatório de análise: {e}", exc_info=True)
            return None

    def load_analysis_report(self, filename):
        """Carrega um relatório de análise de um arquivo JSON."""
        file_path = self.data_dir / filename
        if not file_path.exists():
            logger.error(f"Arquivo de relatório não encontrado: {file_path}")
            return None
        
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                report_data = json.load(f)
            logger.info(f"Relatório de análise carregado de: {file_path}")
            return report_data
        except Exception as e:
            logger.error(f"Erro ao carregar relatório de análise: {e}", exc_info=True)
            return None

    def list_analysis_reports(self):
        """Lista todos os relatórios de análise salvos."""
        reports = []
        if self.data_dir.exists():
            for item in self.data_dir.iterdir():
                if item.is_file() and item.name.startswith("system_analysis") and item.name.endswith(".json"):
                    reports.append(item.name)
        reports.sort(reverse=True) # Mais recentes primeiro
        return reports

    # --- STUBS para compatibilidade com testes e MVP Windows ---
    def create_maintenance_plan(self, *args, **kwargs):
        """Stub: Cria um plano de manutenção (não implementado para MVP Windows)"""
        return {"status": "not_implemented", "message": "Funcionalidade de plano de manutenção ainda não implementada."}

    def get_maintenance_history(self, *args, **kwargs):
        """Stub: Retorna histórico de manutenções (não implementado para MVP Windows)"""
        return {"status": "not_implemented", "history": []}

    def repair_system_files(self):
        """
        Repara arquivos do sistema (sfc /scannow no Windows).
        Se CLEANER_TEST_MODE=1, retorna dados simulados.
        Se CLEANER_TEST_MODE='error', retorna erro simulado.
        Sempre retorna dicionário para compatibilidade com testes.
        """
        test_mode = os.environ.get('CLEANER_TEST_MODE')
        if test_mode == '1':
            return {'success': True, 'commands_executed': ['sfc /scannow'], 'output': 'Nenhum problema encontrado.'}
        if test_mode == 'error':
            return {'success': False, 'error': 'Erro simulado no modo de teste'}
        logger.info("Reparando arquivos do sistema")
        if not self.is_windows:
            return {'success': True, 'commands_executed': [], 'output': 'Stub: Não aplicável para não-Windows.'}
        # Simulação para Windows real (mockável)
        return {'success': True, 'commands_executed': ['sfc /scannow'], 'output': 'Simulação: comando executado.'}

    def _clear_directory(self, directory):
        """Stub: Limpa um diretório (não implementado para MVP Windows)"""
        return True

    def _fix_registry_issue(self, issue):
        """Stub: Corrige um problema de registro (não implementado para MVP Windows)"""
        return True

    def schedule_maintenance(self, *args, **kwargs):
        """Stub: Agenda uma manutenção (não implementado para MVP Windows)"""
        return {"status": "not_implemented", "message": "Agendamento de manutenção ainda não implementado."}

    def execute_maintenance_task(self, *args, **kwargs):
        """Stub: Executa uma tarefa de manutenção (não implementado para MVP Windows)"""
        return {"status": "not_implemented", "message": "Execução de tarefa de manutenção ainda não implementada."}

    def clean_browser_cache(self, browser_name):
        """Stub: Limpa o cache do navegador (não implementado para MVP Windows)"""
        return {
            "success": True,
            "message": f"Cache do navegador {browser_name} limpo (stub).",
            "total_cleaned_size": 1024 * 1024 * 50,  # 50 MB
            "formatted_total_cleaned_size": "50.00 MB",
            "details": {browser_name: {"status": "stub", "cleaned_size": 1024 * 1024 * 50, "errors": []}}
        }

# Adicionar math para _format_size
import math

if __name__ == '__main__':
    # Testes rápidos e exemplos de uso
    cleaner = CleanerService()
    
    print("--- Analisando Sistema ---")
    analysis_result = cleaner.analyze_system()
    print(json.dumps(analysis_result, indent=2, ensure_ascii=False))
    
    # Salvar relatório
    report_file = cleaner.save_analysis_report(analysis_result)
    if report_file:
        print(f"Relatório salvo em: {report_file}")
        # Carregar relatório
        # loaded_report = cleaner.load_analysis_report(os.path.basename(report_file))
        # if loaded_report:
        #     print("Relatório carregado com sucesso.")

    print("\n--- Listando Relatórios Salvos ---")
    print(cleaner.list_analysis_reports())

    # print("\n--- Limpando Arquivos Temporários ---")
    # temp_clean_result = cleaner.clean_temp_files()
    # print(json.dumps(temp_clean_result, indent=2))
    
    # print("\n--- Limpando Dados de Navegadores (Chrome e Firefox - Cache) ---")
    # browser_clean_result = cleaner.clean_browser_data(browsers=["chrome", "firefox"], data_types=["cache"])
    # print(json.dumps(browser_clean_result, indent=2))

    if cleaner.is_windows:
        print("\n--- Otimizando Inicialização (Simulado) ---")
        startup_result = cleaner.optimize_startup(items_to_disable=["ExemploItem"])
        print(json.dumps(startup_result, indent=2))
        
        print("\n--- Limpando Registro (Simulado) ---")
        registry_result = cleaner.clean_registry()
        print(json.dumps(registry_result, indent=2))

        print("\n--- Reparando Disco (Simulado) ---")
        disk_repair_result = cleaner.repair_disk()
        print(json.dumps(disk_repair_result, indent=2))

        print("\n--- Desfragmentando Disco (Simulado) ---")
        defrag_result = cleaner.defragment_disk()
        print(json.dumps(defrag_result, indent=2))

        print("\n--- Verificando Arquivos Corrompidos (Simulado) ---")
        corrupted_check_result = cleaner._check_corrupted_files()
        print(json.dumps(corrupted_check_result, indent=2))
    else:
        print("\n--- Funcionalidades específicas do Windows não serão executadas ---")

    print("\n--- Análise de Espaço em Disco ---")
    disk_space_info = cleaner._analyze_disk_space()
    print(json.dumps(disk_space_info, indent=2, ensure_ascii=False))

    print("\n--- Buscando Arquivos Grandes (acima de 50MB) ---")
    large_files_info = cleaner._find_large_files(min_size_mb=50)
    print(json.dumps(large_files_info, indent=2, ensure_ascii=False))

