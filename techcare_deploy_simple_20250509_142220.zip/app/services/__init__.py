# Este arquivo está vazio intencionalmente para marcar o diretório como um pacote Python
from app.services.diagnostic_service import DiagnosticService
from app.services.repair_service import RepairService
from app.services.driver_update_service import DriverUpdateService
from app.services.cleaner_service import CleanerService 