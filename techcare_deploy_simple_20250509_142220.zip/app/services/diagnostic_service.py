import logging
import sys
import os
import platform
import psutil
import json
import time
import re
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import cpuinfo
from pathlib import Path
import uuid

from app.services.diagnostic_repository import DiagnosticRepository
from app.utils.cache import cache_result

# Importações específicas para detecção de plataforma
from app.services.diagnostic_service_platform import PlatformAdapter, is_windows, is_linux, is_macos

# Importar módulos específicos do Windows apenas se estiver em ambiente Windows
if is_windows():
    try:
        import wmi
        import win32com.client
        from win32com.client import Dispatch
    except ImportError:
        logging.warning("Módulos do Windows (wmi, win32com) não puderam ser importados.")

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(sys.stdout)
    ]
)

logger = logging.getLogger(__name__)

class DiagnosticService:
    """
    Classe responsável pelo diagnóstico completo do sistema.
    Realiza análises de hardware e software, identifica problemas e gera recomendações.
    """
    
    def __init__(self, diagnostic_repository: Optional[DiagnosticRepository] = None):
        """
        Inicializa o serviço de diagnóstico
        
        Args:
            diagnostic_repository: Repositório para armazenamento de diagnósticos
        """
        self.results = {
            'cpu': {},
            'memory': {},
            'disk': {},
            'startup': {},
            'drivers': {},
            'security': {},
            'network': {},
            'temperature': {}  # Adicionando seção para temperatura
        }
        self.problems = []
        self.score = 100  # Pontuação inicial do sistema
        self.is_windows = platform.system() == 'Windows'
        
        # Injeção de dependência do repositório
        self.repository = diagnostic_repository or DiagnosticRepository()
        
        logger.info(f"Iniciando DiagnosticService no sistema {platform.system()}")

    def run_diagnostics(self, user_id: str = 'anonymous') -> Dict[str, Any]:
        """
        Executa um diagnóstico completo do sistema e salva no histórico
        Se DIAGNOSTIC_TEST_MODE=1, retorna dados simulados para ambiente de teste.
        """
        if os.environ.get('DIAGNOSTIC_TEST_MODE') == '1':
            diagnostic_result = {
                'id': f'diag-test-{user_id}',
                'user_id': user_id,
                'timestamp': '2024-06-01T12:00:00',
                'score': 90,
                'cpu': {'usage': 35, 'status': 'good'},
                'memory': {'usage': 60, 'status': 'good'},
                'disk': {'usage': 75, 'status': 'warning'},
                'network': {'status': 'ok', 'adapters': []},
                'problems': [],
                'recommendations': ['Tudo ok no ambiente de teste.']
            }
            self.repository.save(diagnostic_result)
            return diagnostic_result
        logger.info(f"Iniciando diagnóstico via run_diagnostics para usuário {user_id}")
        diagnostic_result = self.start_diagnostic()
        
        # Adiciona informações do usuário
        diagnostic_result['user_id'] = user_id
        
        # Salva o diagnóstico no repositório
        self.repository.save(diagnostic_result)
        
        return diagnostic_result

    def save_diagnostic(self, diagnostic_data: Dict[str, Any]) -> bool:
        """
        Salva um diagnóstico no histórico
        
        Args:
            diagnostic_data: Dados do diagnóstico a serem salvos
            
        Returns:
            bool: True se o salvamento foi bem-sucedido
        """
        try:
            self.repository.save(diagnostic_data)
            return True
        except Exception as e:
            logger.error(f"Erro ao salvar diagnóstico: {e}")
            return False
        
    def get_diagnostic_history(self, user_id: str = 'anonymous', limit: int = 10) -> List[Dict[str, Any]]:
        """
        Recupera o histórico de diagnósticos para um usuário
        
        Args:
            user_id: ID do usuário
            limit: Número máximo de registros a retornar
            
        Returns:
            list: Lista de diagnósticos resumidos, ordenados por data (mais recente primeiro)
        """
        return self.repository.get_history(user_id, limit)
        
    def get_diagnostic_by_id(self, diagnostic_id: str, user_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        """
        Recupera um diagnóstico específico pelo ID
        
        Args:
            diagnostic_id: ID do diagnóstico
            user_id: ID do usuário (se None, busca em todos os usuários)
            
        Returns:
            dict: Dados completos do diagnóstico ou None se não encontrado
        """
        return self.repository.get_by_id(diagnostic_id, user_id)
        
    def get_all_diagnostics(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Recupera diagnósticos de todos os usuários (para administradores)
        
        Args:
            limit: Número máximo de registros a retornar
            
        Returns:
            list: Lista de diagnósticos resumidos de todos os usuários
        """
        return self.repository.get_all(limit)

    @cache_result(expire_seconds=300)  # Cache por 5 minutos
    def start_diagnostic(self) -> Dict[str, Any]:
        """
        Inicia o diagnóstico completo do sistema
        
        Returns:
            dict: Resultados completos do diagnóstico
        """
        logger.info("Iniciando diagnóstico completo do sistema")
        
        try:
            # Executa cada análise em sequência
            self.analyze_cpu()
            self.analyze_memory()
            self.analyze_disk()
            
            # Análises específicas para Windows
            if self.is_windows:
                self.analyze_startup()
            
            # Análises comuns
            self.analyze_drivers()
            self.analyze_security()
            self.analyze_temperature()
            self.analyze_network()
            
            # Gera relatório e recomendações
            diagnostic_report = self.generate_report()
            
            # Adiciona identificador único e timestamp
            diagnostic_report['id'] = f"diag-{uuid.uuid4().hex[:8]}"
            diagnostic_report['timestamp'] = datetime.now().isoformat()
            
            logger.info(f"Diagnóstico completo concluído com sucesso, ID: {diagnostic_report['id']}")
            return diagnostic_report
            
        except Exception as e:
            logger.error(f"Erro durante o diagnóstico: {e}")
            # Em caso de erro, retorna um relatório básico com a mensagem de erro
            error_report = {
                'id': f"error-{uuid.uuid4().hex[:8]}",
                'timestamp': datetime.now().isoformat(),
                'error': str(e),
                'score': 0,
                'problems': [f"Erro durante diagnóstico: {e}"],
                'recommendations': ["Tente novamente o diagnóstico ou contate o suporte."]
            }
            return error_report
    
    def analyze_cpu(self) -> Dict[str, Any]:
        """Analisa a CPU do sistema e retorna métricas relevantes"""
        logger.info("Analisando CPU...")
        
        try:
            # Usar o PlatformAdapter para obter informações da CPU de forma compatível
            cpu_info = PlatformAdapter.get_cpu_info()
            
            # Métricas de uso
            cpu_percent = psutil.cpu_percent(interval=0.5, percpu=False)
            cpu_percent_per_core = psutil.cpu_percent(interval=0.1, percpu=True)
            cpu_freq = psutil.cpu_freq()
            
            # Resultados básicos
            result = {
                'usage': cpu_percent,
                'usage_per_core': cpu_percent_per_core,
                'current_frequency': cpu_freq.current if cpu_freq else None,
                'max_frequency': cpu_freq.max if cpu_freq and hasattr(cpu_freq, 'max') else None,
                'cores_logical': cpu_info['cores_logical'],
                'cores_physical': cpu_info['cores_physical'],
                'vendor': cpu_info['vendor'],
                'brand': cpu_info['brand'],
                'architecture': cpu_info['architecture'],
                'temperature': cpu_info['temperature'],
                'is_overheating': False,
                'is_throttling': False,
                'issues': []
            }
            
            # Verificação de problemas
            # 1. Temperatura (se disponível)
            if result['temperature'] is not None:
                if result['temperature'] > 85:
                    result['is_overheating'] = True
                    result['issues'].append({
                        'severity': 'high',
                        'description': f'Temperatura crítica de CPU ({result["temperature"]}°C)',
                        'recommendation': 'Verifique a ventilação e os dissipadores de calor do sistema.'
                    })
                elif result['temperature'] > 75:
                    result['issues'].append({
                        'severity': 'medium',
                        'description': f'Temperatura elevada de CPU ({result["temperature"]}°C)',
                        'recommendation': 'Considere limpar os ventiladores e verificar a pasta térmica.'
                    })
            
            # 2. Uso de CPU
            if result['usage'] > 90:
                result['issues'].append({
                    'severity': 'high',
                    'description': f'Uso extremamente alto de CPU ({result["usage"]}%)',
                    'recommendation': 'Verifique quais processos estão consumindo a CPU e encerre os desnecessários.'
                })
            elif result['usage'] > 80:
                result['issues'].append({
                    'severity': 'medium',
                    'description': f'Uso elevado de CPU ({result["usage"]}%)',
                    'recommendation': 'Monitore os processos em execução que podem estar sobrecarregando o sistema.'
                })
            
            # 3. Verificação de throttling (limitação de velocidade)
            if cpu_freq and hasattr(cpu_freq, 'max') and hasattr(cpu_freq, 'current'):
                if cpu_freq.current < (cpu_freq.max * 0.7) and result['usage'] > 70:
                    result['is_throttling'] = True
                    result['issues'].append({
                        'severity': 'medium',
                        'description': f'CPU possivelmente limitada (throttling)',
                        'recommendation': 'Verifique a temperatura, energia e configurações de gerenciamento de energia.'
                    })
            
            # 4. Verificação de cores
            if result['cores_physical'] == 1:
                result['issues'].append({
                    'severity': 'low',
                    'description': 'CPU com número limitado de núcleos físicos',
                    'recommendation': 'Considere um upgrade de hardware para aplicações mais exigentes.'
                })
            
            # Verifica se existe algum problema para determinar a saúde
            health_status = 100
            for issue in result['issues']:
                if issue['severity'] == 'high':
                    health_status -= 20
                elif issue['severity'] == 'medium':
                    health_status -= 10
                elif issue['severity'] == 'low':
                    health_status -= 5
            
            result['health_status'] = max(health_status, 0)
            
            logger.info(f"Análise de CPU concluída. Saúde: {result['health_status']}%")
            return result
            
        except Exception as e:
            logger.error(f"Erro ao analisar CPU: {str(e)}")
            return {
                'error': str(e),
                'usage': 0,
                'cores_logical': 0,
                'cores_physical': 0,
                'health_status': 0,
                'issues': [
                    {
                        'severity': 'high',
                        'description': f'Erro ao analisar CPU: {str(e)}',
                        'recommendation': 'Verifique os logs para mais detalhes.'
                    }
                ]
            }
    
    def analyze_memory(self) -> Dict[str, Any]:
        """Analisa a memória RAM do sistema e retorna métricas relevantes"""
        logger.info("Analisando memória RAM...")
        
        try:
            # Usar o PlatformAdapter para obter informações de memória de forma compatível
            memory_info = PlatformAdapter.get_memory_info()
            
            # Métricas de uso
            top_memory_processes = []
            for proc in sorted(psutil.process_iter(['pid', 'name', 'memory_percent']), 
                              key=lambda p: p.info['memory_percent'] if 'memory_percent' in p.info else 0, 
                              reverse=True)[:5]:
                try:
                    if proc.info.get('memory_percent', 0) > 0:
                        top_memory_processes.append({
                            'pid': proc.info['pid'],
                            'name': proc.info['name'],
                            'memory_percent': proc.info.get('memory_percent', 0),
                            'memory_mb': proc.memory_info().rss // (1024 ** 2) if hasattr(proc, 'memory_info') else 0  # MB
                        })
                except (psutil.NoSuchProcess, psutil.AccessDenied, AttributeError):
                    pass
            
            # Resultados básicos
            result = {
                'total': memory_info['total'],
                'total_gb': memory_info['total'] / (1024 ** 3),
                'available': memory_info['available'],
                'available_gb': memory_info['available'] / (1024 ** 3),
                'used': memory_info['used'],
                'used_gb': memory_info['used'] / (1024 ** 3),
                'percent': memory_info['percent'],
                'swap_total': memory_info['swap_total'],
                'swap_total_gb': memory_info['swap_total'] / (1024 ** 3),
                'swap_used': memory_info['swap_used'],
                'swap_used_gb': memory_info['swap_used'] / (1024 ** 3),
                'swap_percent': memory_info['swap_percent'],
                'top_processes': top_memory_processes,
                'issues': []
            }
            
            # Verificação de problemas
            # 1. Verificar uso de memória RAM
            if result['percent'] > 90:
                result['issues'].append({
                    'severity': 'high',
                    'description': f"Memória RAM quase esgotada ({result['percent']}%)",
                    'recommendation': 'Feche programas não utilizados, reinicie o computador, ou considere aumentar a quantidade de RAM.'
                })
            elif result['percent'] > 80:
                result['issues'].append({
                    'severity': 'medium',
                    'description': f"Uso alto de memória RAM ({result['percent']}%)",
                    'recommendation': 'Feche programas não utilizados para liberar memória.'
                })
            
            # 2. Verificar quantidade total de RAM
            total_ram_gb = result['total_gb']
            if total_ram_gb < 4:
                result['issues'].append({
                    'severity': 'high',
                    'description': f"Pouca memória RAM ({total_ram_gb:.1f} GB)",
                    'recommendation': 'Considere atualizar sua memória RAM para pelo menos 8GB.'
                })
            elif total_ram_gb < 8:
                result['issues'].append({
                    'severity': 'medium',
                    'description': f"Memória RAM limitada ({total_ram_gb:.1f} GB)",
                    'recommendation': 'Considere atualizar sua memória RAM para 16GB ou mais para melhor desempenho.'
                })
            
            # 3. Verificar uso excessivo de swap
            if result['swap_percent'] > 80 and result['swap_total'] > 0:
                result['issues'].append({
                    'severity': 'high',
                    'description': f"Uso excessivo de memória swap ({result['swap_percent']}%)",
                    'recommendation': 'Feche programas não utilizados ou aumente a memória RAM física.'
                })
            
            # Verifica se existe algum problema para determinar a saúde
            health_status = 100
            for issue in result['issues']:
                if issue['severity'] == 'high':
                    health_status -= 20
                elif issue['severity'] == 'medium':
                    health_status -= 10
                elif issue['severity'] == 'low':
                    health_status -= 5
            
            result['health_status'] = max(health_status, 0)
            
            logger.info(f"Análise de memória concluída. Total: {total_ram_gb:.1f}GB, Uso: {result['percent']}%, Saúde: {result['health_status']}%")
            return result
            
        except Exception as e:
            logger.error(f"Erro ao analisar memória: {str(e)}")
            return {
                'error': str(e),
                'total': 0,
                'available': 0,
                'used': 0,
                'percent': 0,
                'health_status': 0,
                'issues': [
                    {
                        'severity': 'high',
                        'description': f'Erro ao analisar memória: {str(e)}',
                        'recommendation': 'Verifique os logs para mais detalhes.'
                    }
                ]
            }
    
    def analyze_disk(self):
        """Analisa os discos do sistema"""
        logger.info("Analisando discos")
        
        self.results['disk']['partitions'] = []
        total_disk_score = 0
        partition_count = 0
        
        # Analisa cada partição do sistema
        for partition in psutil.disk_partitions():
            try:
                # Pula dispositivos de rede ou CD-ROM em sistemas Windows
                if self.is_windows and ('cdrom' in partition.opts or partition.fstype == ''):
                    continue
                
                usage = psutil.disk_usage(partition.mountpoint)
                
                # Processa os valores em variáveis antes de formatar para evitar problemas com mocks
                try:
                    total_gb = usage.total / (1024 ** 3)
                    used_gb = usage.used / (1024 ** 3)
                    free_gb = usage.free / (1024 ** 3)
                    percent = usage.percent
                    
                    # Formata para duas casas decimais
                    if isinstance(total_gb, (int, float)):
                        total_gb = round(total_gb, 2)
                    if isinstance(used_gb, (int, float)):
                        used_gb = round(used_gb, 2)
                    if isinstance(free_gb, (int, float)):
                        free_gb = round(free_gb, 2)
                    if isinstance(percent, (int, float)):
                        percent = round(percent, 2)
                except (AttributeError, TypeError):
                    # Se ocorrer erro na formatação, usa os valores brutos
                    total_gb = usage.total / (1024 ** 3)
                    used_gb = usage.used / (1024 ** 3)
                    free_gb = usage.free / (1024 ** 3)
                    percent = usage.percent
                
                partition_info = {
                    'device': partition.device,
                    'mountpoint': partition.mountpoint,
                    'fstype': partition.fstype,
                    'total_gb': total_gb,
                    'used_gb': used_gb,
                    'free_gb': free_gb,
                    'percent': percent
                }
                
                # Verifica espaço disponível
                partition_score = 100
                
                if percent > 95:
                    self.problems.append({
                        'category': 'disk',
                        'title': f'Disco {partition.device} criticamente cheio',
                        'description': f'O disco {partition.device} está com {percent}% de uso, com apenas {free_gb}GB livres.',
                        'solution': 'Libere espaço urgentemente removendo arquivos temporários, aplicativos não utilizados e considere transferir arquivos para armazenamento externo.',
                        'impact': 'high'
                    })
                    partition_score -= 40
                elif percent > 85:
                    self.problems.append({
                        'category': 'disk',
                        'title': f'Disco {partition.device} quase cheio',
                        'description': f'O disco {partition.device} está com {percent}% de uso.',
                        'solution': 'Libere espaço removendo arquivos temporários e aplicativos não utilizados.',
                        'impact': 'medium'
                    })
                    partition_score -= 20
                
                # Verifica se o disco é SSD ou HDD (apenas Windows por enquanto)
                if self.is_windows:
                    try:
                        disk_type = self._get_disk_type_windows(partition.device)
                        partition_info['type'] = disk_type
                        
                        # Penaliza HDDs para sistemas modernos
                        if disk_type == 'HDD' and partition.mountpoint == 'C:\\':
                            self.problems.append({
                                'category': 'disk',
                                'title': 'Disco de sistema é HDD',
                                'description': 'Seu disco de sistema é um HDD (disco rígido mecânico), o que limita significativamente o desempenho geral do sistema.',
                                'solution': 'Considere atualizar para um SSD para melhorar drasticamente a velocidade de inicialização e resposta do sistema.',
                                'impact': 'medium'
                            })
                            partition_score -= 25
                    except Exception as e:
                        logger.warning(f"Não foi possível determinar o tipo de disco para {partition.device}: {str(e)}")
                
                # Verificação de fragmentação (apenas Windows)
                if self.is_windows and partition.fstype.lower() in ['ntfs', 'fat32']:
                    try:
                        fragmentation = self._check_fragmentation_windows(partition.device)
                        if fragmentation:
                            # Evita problema de formatação com objetos mock
                            if isinstance(fragmentation, (int, float)):
                                fragmentation = round(fragmentation, 2)
                            
                            partition_info['fragmentation'] = fragmentation
                            
                            if fragmentation > 20:
                                self.problems.append({
                                    'category': 'disk',
                                    'title': f'Disco {partition.device} fragmentado',
                                    'description': f'O disco {partition.device} está com {fragmentation}% de fragmentação.',
                                    'solution': 'Execute a desfragmentação do disco para melhorar o desempenho.',
                                    'impact': 'medium'
                                })
                                partition_score -= 15
                    except Exception as e:
                        logger.warning(f"Não foi possível verificar a fragmentação para {partition.device}: {str(e)}")
                
                partition_info['score'] = partition_score
                self.results['disk']['partitions'].append(partition_info)
                
                # Atualiza a pontuação total dos discos
                total_disk_score += partition_score
                partition_count += 1
            
            except PermissionError:
                logger.warning(f"Permissão negada ao analisar a partição {partition.mountpoint}")
                continue
            except Exception as e:
                logger.warning(f"Erro ao analisar a partição {partition.mountpoint}: {str(e)}")
                continue
        
        # Calcula a pontuação média dos discos
        if partition_count > 0:
            disk_score = total_disk_score / partition_count
            self.score -= (100 - disk_score) * 0.2  # Impacto de 20% na pontuação total
        
        logger.info(f"Análise de discos concluída. Partições analisadas: {partition_count}")
    
    def analyze_startup(self):
        """Analisa programas de inicialização (apenas Windows)"""
        if not self.is_windows:
            logger.info("Análise de inicialização ignorada - não é um sistema Windows")
            return
        
        logger.info("Analisando programas de inicialização")
        
        try:
            import winreg
            
            startup_locations = [
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\Run",
                r"SOFTWARE\Microsoft\Windows\CurrentVersion\RunOnce",
                r"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\Run",
                r"SOFTWARE\Wow6432Node\Microsoft\Windows\CurrentVersion\RunOnce"
            ]
            
            startup_items = []
            
            # Verifica no registro do Windows
            for location in startup_locations:
                try:
                    reg = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, location)
                    
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(reg, i)
                            startup_items.append({
                                'name': name,
                                'command': value,
                                'location': f"HKLM\\{location}"
                            })
                            i += 1
                        except WindowsError:
                            break
                    
                    winreg.CloseKey(reg)
                except WindowsError:
                    continue
                
                try:
                    reg = winreg.OpenKey(winreg.HKEY_CURRENT_USER, location)
                    
                    i = 0
                    while True:
                        try:
                            name, value, _ = winreg.EnumValue(reg, i)
                            startup_items.append({
                                'name': name,
                                'command': value,
                                'location': f"HKCU\\{location}"
                            })
                            i += 1
                        except WindowsError:
                            break
                    
                    winreg.CloseKey(reg)
                except WindowsError:
                    continue
            
            # Verifica nas pastas de inicialização
            startup_folders = [
                os.path.join(os.environ["APPDATA"], r"Microsoft\Windows\Start Menu\Programs\Startup"),
                os.path.join(os.environ["ALLUSERSPROFILE"], r"Microsoft\Windows\Start Menu\Programs\Startup")
            ]
            
            for folder in startup_folders:
                if os.path.exists(folder):
                    for file in os.listdir(folder):
                        file_path = os.path.join(folder, file)
                        if os.path.isfile(file_path) and (file.endswith('.lnk') or file.endswith('.url')):
                            startup_items.append({
                                'name': file,
                                'command': file_path,
                                'location': folder
                            })
            
            self.results['startup']['items'] = startup_items
            
            # Avaliação de programas de inicialização
            if len(startup_items) > 15:
                self.problems.append({
                    'category': 'startup',
                    'title': 'Excesso de programas na inicialização',
                    'description': f'Existem {len(startup_items)} programas configurados para iniciar com o Windows, o que aumenta significativamente o tempo de inicialização.',
                    'solution': 'Desative programas desnecessários na inicialização usando o Gerenciador de Tarefas.',
                    'impact': 'high'
                })
                self.score -= 15
            elif len(startup_items) > 8:
                self.problems.append({
                    'category': 'startup',
                    'title': 'Muitos programas na inicialização',
                    'description': f'Existem {len(startup_items)} programas configurados para iniciar com o Windows.',
                    'solution': 'Considere desativar programas não essenciais na inicialização para melhorar o tempo de boot.',
                    'impact': 'medium'
                })
                self.score -= 8
            
            logger.info(f"Análise de inicialização concluída. Programas encontrados: {len(startup_items)}")
        
        except Exception as e:
            logger.error(f"Erro ao analisar programas de inicialização: {str(e)}", exc_info=True)
            self.results['startup']['error'] = str(e)
    
    def analyze_drivers(self):
        """Analisa drivers do sistema (apenas Windows)"""
        if not self.is_windows:
            logger.info("Análise de drivers ignorada - não é um sistema Windows")
            return
        
        logger.info("Analisando drivers do sistema")
        
        try:
            import wmi
            
            w = wmi.WMI()
            drivers = w.Win32_PnPSignedDriver()
            
            self.results['drivers']['count'] = len(drivers)
            self.results['drivers']['outdated'] = []
            self.results['drivers']['problematic'] = []
            
            # Lista de drivers com potenciais problemas
            problematic_drivers = []
            outdated_drivers = []
            
            for driver in drivers:
                driver_info = {
                    'name': driver.DeviceName,
                    'manufacturer': driver.Manufacturer,
                    'version': driver.DriverVersion
                }
                
                # Verificar drivers com problemas
                if hasattr(driver, 'Status') and driver.Status and driver.Status.lower() != 'ok':
                    driver_info['status'] = driver.Status
                    problematic_drivers.append(driver_info)
                
                # Verificar drivers desatualizados
                # Nota: Esta é uma verificação simples baseada na data. Uma verificação real
                # exigiria uma base de dados de drivers atualizados ou consulta a serviços online.
                if hasattr(driver, 'DriverDate') and driver.DriverDate:
                    driver_date = driver.DriverDate
                    if isinstance(driver_date, str) and len(driver_date) > 8:
                        try:
                            # Formato WMI: YYYYMMDDHHMMSS.mmmmmm+UUU
                            year = int(driver_date[:4])
                            current_year = datetime.now().year
                            
                            if (current_year - year) > 3:
                                driver_info['driver_date'] = driver_date
                                driver_info['age_years'] = current_year - year
                                outdated_drivers.append(driver_info)
                        except ValueError:
                            pass
            
            self.results['drivers']['problematic'] = problematic_drivers
            self.results['drivers']['outdated'] = outdated_drivers
            
            # Avaliação de drivers
            if len(problematic_drivers) > 0:
                self.problems.append({
                    'category': 'drivers',
                    'title': 'Drivers com problemas',
                    'description': f'Foram encontrados {len(problematic_drivers)} drivers com problemas que podem afetar o funcionamento do sistema.',
                    'solution': 'Atualize ou reinstale os drivers problemáticos usando o Gerenciador de Dispositivos.',
                    'impact': 'high'
                })
                self.score -= 15
            
            if len(outdated_drivers) > 5:
                self.problems.append({
                    'category': 'drivers',
                    'title': 'Muitos drivers desatualizados',
                    'description': f'Foram encontrados {len(outdated_drivers)} drivers com mais de 3 anos sem atualização.',
                    'solution': 'Atualize os drivers mais importantes, especialmente os de vídeo, rede e chipset.',
                    'impact': 'medium'
                })
                self.score -= 10
            elif len(outdated_drivers) > 0:
                self.problems.append({
                    'category': 'drivers',
                    'title': 'Drivers desatualizados',
                    'description': f'Foram encontrados {len(outdated_drivers)} drivers com mais de 3 anos sem atualização.',
                    'solution': 'Considere atualizar esses drivers para melhorar a estabilidade e desempenho.',
                    'impact': 'low'
                })
                self.score -= 5
            
            logger.info(f"Análise de drivers concluída. Total: {len(drivers)}, Problemáticos: {len(problematic_drivers)}, Desatualizados: {len(outdated_drivers)}")
        
        except Exception as e:
            logger.error(f"Erro ao analisar drivers: {str(e)}", exc_info=True)
            self.results['drivers']['error'] = str(e)
    
    def analyze_security(self):
        """Analisa a segurança do sistema (apenas Windows)"""
        if not self.is_windows:
            logger.info("Análise de segurança ignorada - não é um sistema Windows")
            return
        
        logger.info("Analisando segurança do sistema")
        
        try:
            import wmi
            
            w = wmi.WMI()
            
            # Verifica o Windows Defender
            try:
                defender_status = self._check_windows_defender()
                self.results['security']['antivirus'] = defender_status
                
                if not defender_status.get('real_time_protection', True):
                    self.problems.append({
                        'category': 'security',
                        'title': 'Proteção em tempo real desativada',
                        'description': 'A proteção em tempo real do Windows Defender está desativada, deixando seu sistema vulnerável.',
                        'solution': 'Ative a proteção em tempo real do Windows Defender ou instale outro antivírus.',
                        'impact': 'high'
                    })
                    self.score -= 20
            except Exception as e:
                logger.warning(f"Não foi possível verificar o status do Windows Defender: {str(e)}")
                self.results['security']['antivirus'] = {'error': str(e)}
            
            # Verifica o Firewall do Windows
            try:
                firewall_status = self._check_windows_firewall()
                self.results['security']['firewall'] = firewall_status
                
                if not firewall_status.get('enabled', True):
                    self.problems.append({
                        'category': 'security',
                        'title': 'Firewall desativado',
                        'description': 'O Firewall do Windows está desativado, o que pode comprometer a segurança da rede.',
                        'solution': 'Ative o Firewall do Windows ou instale outro firewall.',
                        'impact': 'high'
                    })
                    self.score -= 15
            except Exception as e:
                logger.warning(f"Não foi possível verificar o status do Firewall do Windows: {str(e)}")
                self.results['security']['firewall'] = {'error': str(e)}
            
            # Verifica atualizações do Windows
            try:
                updates_status = self._check_windows_updates()
                self.results['security']['updates'] = updates_status
                
                if updates_status.get('pending_count', 0) > 10:
                    self.problems.append({
                        'category': 'security',
                        'title': 'Atualizações pendentes',
                        'description': f'Existem {updates_status["pending_count"]} atualizações do Windows pendentes.',
                        'solution': 'Execute o Windows Update para instalar todas as atualizações pendentes.',
                        'impact': 'high'
                    })
                    self.score -= 15
                elif updates_status.get('pending_count', 0) > 0:
                    self.problems.append({
                        'category': 'security',
                        'title': 'Algumas atualizações pendentes',
                        'description': f'Existem {updates_status["pending_count"]} atualizações do Windows pendentes.',
                        'solution': 'Execute o Windows Update para manter seu sistema atualizado.',
                        'impact': 'medium'
                    })
                    self.score -= 8
            except Exception as e:
                logger.warning(f"Não foi possível verificar as atualizações do Windows: {str(e)}")
                self.results['security']['updates'] = {'error': str(e)}
            
            logger.info("Análise de segurança concluída")
        
        except Exception as e:
            logger.error(f"Erro ao analisar segurança: {str(e)}", exc_info=True)
            self.results['security']['error'] = str(e)
    
    def _check_windows_defender(self):
        """Verifica o status do Windows Defender"""
        result = {}
        
        try:
            import wmi
            w = wmi.WMI(namespace="root\\Microsoft\\Windows\\Defender")
            
            # Verifica o status do serviço
            defender = w.MSFT_MpComputerStatus()[0]
            
            result['product_name'] = 'Windows Defender'
            result['real_time_protection'] = defender.RealTimeProtectionEnabled
            result['antivirus_enabled'] = defender.AntivirusEnabled
            result['antispyware_enabled'] = defender.AntispywareEnabled
            result['last_scan'] = str(defender.LastFullScanDateTime or '')
            result['last_definition_update'] = str(defender.AntivirusSignatureLastUpdated or '')
            result['days_since_last_update'] = (datetime.now() - defender.AntivirusSignatureLastUpdated).days if defender.AntivirusSignatureLastUpdated else -1
        except Exception as e:
            # Tenta um método alternativo se falhar
            try:
                result = self._check_defender_with_powershell()
            except Exception as inner_e:
                logger.error(f"Erro ao verificar Windows Defender: {str(inner_e)}")
                result['error'] = str(inner_e)
        
        return result
    
    def _check_defender_with_powershell(self):
        """Verifica o status do Windows Defender usando PowerShell"""
        result = {}
        
        try:
            # Executa o comando PowerShell para verificar o status do Windows Defender
            cmd = ['powershell', '-Command', 'Get-MpComputerStatus | ConvertTo-Json']
            process = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            if process.returncode == 0 and process.stdout:
                status = json.loads(process.stdout)
                
                result['product_name'] = 'Windows Defender'
                result['real_time_protection'] = status.get('RealTimeProtectionEnabled', False)
                result['antivirus_enabled'] = status.get('AntivirusEnabled', False)
                result['antispyware_enabled'] = status.get('AntispywareEnabled', False)
                result['last_scan'] = status.get('LastFullScanDateTime', '')
                result['last_definition_update'] = status.get('AntivirusSignatureLastUpdated', '')
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def _check_windows_firewall(self):
        """Verifica o status do Firewall do Windows"""
        result = {}
        
        try:
            # Executa o comando para verificar o status do firewall
            cmd = ['netsh', 'advfirewall', 'show', 'allprofiles']
            process = subprocess.run(cmd, capture_output=True, text=True, check=True)
            
            if process.returncode == 0:
                output = process.stdout
                
                # Processa a saída para extrair o status
                profiles = {
                    'Domain Profile': {},
                    'Private Profile': {},
                    'Public Profile': {}
                }
                
                current_profile = None
                for line in output.splitlines():
                    line = line.strip()
                    
                    # Identifica o perfil atual
                    if line.endswith('Profile Settings:'):
                        current_profile = line.replace('Profile Settings:', '').strip()
                        continue
                    
                    # Extrai o status do firewall para o perfil atual
                    if current_profile and line.startswith('State'):
                        state = line.split(' ', 1)[1].strip()
                        if current_profile in profiles:
                            profiles[current_profile]['enabled'] = (state.upper() == 'ON')
                
                # Verifica se pelo menos um perfil está ativo
                any_enabled = any(profile.get('enabled', False) for profile in profiles.values())
                
                result = {
                    'enabled': any_enabled,
                    'profiles': profiles
                }
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def _check_windows_updates(self):
        """Verifica o status das atualizações do Windows"""
        result = {}
        
        try:
            # Executa o comando PowerShell para verificar atualizações pendentes
            cmd = ['powershell', '-Command', '(New-Object -ComObject Microsoft.Update.Session).CreateUpdateSearcher().Search("IsInstalled=0").Updates.Count']
            process = subprocess.run(cmd, capture_output=True, text=True)
            
            if process.returncode == 0 and process.stdout:
                pending_count = int(process.stdout.strip())
                result['pending_count'] = pending_count
        except Exception as e:
            result['error'] = str(e)
        
        return result
    
    def _get_disk_type_windows(self, drive_letter):
        """Determina se o disco é SSD ou HDD no Windows"""
        # Remove qualquer coisa após : e remove a / (se houver)
        if drive_letter.endswith(':'):
            drive_letter = drive_letter[:2]
        else:
            drive_letter = drive_letter.split(':')[0]
            if drive_letter.startswith('\\'):
                drive_letter = drive_letter.lstrip('\\')
            drive_letter = f"{drive_letter}:"
        
        try:
            # Executa o comando para obter o tipo de mídia
            cmd = ['powershell', '-Command', f'Get-PhysicalDisk | Where-Object {{ $_.DeviceId -eq ((Get-Partition -DriveLetter {drive_letter[0]}).DiskNumber) }} | Select-Object MediaType | ConvertTo-Json']
            process = subprocess.run(cmd, capture_output=True, text=True)
            
            if process.returncode == 0 and process.stdout:
                output = json.loads(process.stdout)
                media_type = output.get('MediaType', 0)
                
                # MediaType: 3 = HDD, 4 = SSD, 5 = SCM
                if media_type == 4:
                    return 'SSD'
                elif media_type == 3:
                    return 'HDD'
                elif media_type == 5:
                    return 'SCM'
                else:
                    return 'Unknown'
        except Exception:
            pass
        
        # Método alternativo se o primeiro falhar
        try:
            cmd = ['wmic', 'diskdrive', 'get', 'Model,SerialNumber,Status,MediaType', '/format:csv']
            process = subprocess.run(cmd, capture_output=True, text=True)
            
            if 'SSD' in process.stdout:
                return 'SSD'
            elif 'HDD' in process.stdout:
                return 'HDD'
        except Exception:
            pass
        
        return 'Unknown'
    
    def _check_fragmentation_windows(self, drive_letter):
        """Verifica a fragmentação do disco no Windows"""
        if not drive_letter.endswith(':'):
            drive_letter = drive_letter[:2]
        
        try:
            # Executa o comando para verificar a fragmentação
            cmd = ['powershell', '-Command', f'$vol = Get-Volume -DriveLetter {drive_letter[0]}; $defrag = Optimize-Volume -DriveLetter {drive_letter[0]} -Analyze -Verbose; $vol | Select-Object FileSystemFragmentation | ConvertTo-Json']
            process = subprocess.run(cmd, capture_output=True, text=True)
            
            if process.returncode == 0 and process.stdout:
                try:
                    output = json.loads(process.stdout)
                    fragmentation = output.get('FileSystemFragmentation', 0)
                    return fragmentation
                except json.JSONDecodeError:
                    # Fallback para extração por expressão regular
                    import re
                    match = re.search(r'FileSystemFragmentation\s*:\s*(\d+)', process.stdout)
                    if match:
                        return int(match.group(1))
        except Exception as e:
            logger.warning(f"Erro ao verificar fragmentação: {str(e)}")
        
        return None
    
    def analyze_temperature(self):
        """Analisa a temperatura dos componentes do sistema"""
        logger.info("Analisando temperatura dos componentes")
        
        temperatures = {}
        
        # Método específico para Windows usando WMI
        if self.is_windows and HAS_WMI:
            try:
                temperatures = self._check_temperatures_windows()
            except Exception as e:
                logger.error(f"Erro ao verificar temperaturas via WMI: {str(e)}")
        
        # Método para Linux usando sensors
        elif platform.system() == 'Linux' and HAS_SENSORS:
            try:
                temperatures = self._check_temperatures_linux()
            except Exception as e:
                logger.error(f"Erro ao verificar temperaturas via sensors: {str(e)}")
        
        # Tenta usar método genérico para ambos sistemas com psutil
        if not temperatures:
            try:
                if hasattr(psutil, "sensors_temperatures"):
                    temps = psutil.sensors_temperatures()
                    if temps:
                        for chip, sensors_list in temps.items():
                            for sensor in sensors_list:
                                if hasattr(sensor, 'current') and sensor.current:
                                    label = sensor.label or f"{chip}_{sensor.index}"
                                    temperatures[label] = sensor.current
            except Exception as e:
                logger.error(f"Erro ao verificar temperaturas via psutil: {str(e)}")
            
        # Se nenhum método funcionou, tenta métodos alternativos
        if not temperatures and self.is_windows:
            try:
                # Tenta usar o OpenHardwareMonitor via comando
                temperatures = self._check_temperatures_alternative_windows()
            except Exception as e:
                logger.error(f"Erro ao verificar temperaturas via método alternativo: {str(e)}")
        
        self.results['temperature']['components'] = temperatures
        
        # Avaliação das temperaturas
        cpu_temp = None
        
        # Tenta identificar a temperatura da CPU entre os valores obtidos
        for key, value in temperatures.items():
            if 'cpu' in key.lower() or 'processor' in key.lower() or 'core' in key.lower():
                if cpu_temp is None or value > cpu_temp:
                    cpu_temp = value
        
        if cpu_temp:
            self.results['temperature']['cpu'] = cpu_temp
            
            # Avaliação da temperatura da CPU
            if cpu_temp > 90:  # Temperatura crítica
                self.problems.append({
                    'category': 'temperature',
                    'title': 'Temperatura da CPU muito alta',
                    'description': f'A CPU está operando a {cpu_temp}°C, o que pode causar danos permanentes ao hardware.',
                    'solution': 'Desligue o computador imediatamente, verifique se as ventoinhas estão funcionando e limpe o sistema de refrigeração.',
                    'impact': 'critical'
                })
                self.score -= 25
            elif cpu_temp > 80:  # Temperatura alta
                self.problems.append({
                    'category': 'temperature',
                    'title': 'Temperatura da CPU alta',
                    'description': f'A CPU está operando a {cpu_temp}°C, o que pode causar instabilidade e redução de desempenho.',
                    'solution': 'Verifique a refrigeração do sistema, limpe o pó interno e considere melhorar o fluxo de ar no gabinete.',
                    'impact': 'high'
                })
                self.score -= 15
            elif cpu_temp > 70:  # Temperatura elevada
                self.problems.append({
                    'category': 'temperature',
                    'title': 'Temperatura da CPU elevada',
                    'description': f'A CPU está operando a {cpu_temp}°C, um pouco acima do ideal para operação prolongada.',
                    'solution': 'Considere melhorar a ventilação do sistema e verificar se os dissipadores de calor estão limpos.',
                    'impact': 'medium'
                })
                self.score -= 5
        else:
            self.results['temperature']['cpu'] = None
            logger.warning("Não foi possível determinar a temperatura da CPU")
        
        logger.info(f"Análise de temperatura concluída. Temperatura CPU: {self.results['temperature'].get('cpu')}°C")
    
    def _check_temperatures_windows(self):
        """Verifica as temperaturas no Windows usando WMI"""
        temperatures = {}
        
        try:
            w = wmi.WMI(namespace="root\\wmi")
            temperature_info = w.MSAcpi_ThermalZoneTemperature()
            
            for temp_info in temperature_info:
                if hasattr(temp_info, 'CurrentTemperature'):
                    # Convertendo de Kelvin * 10 para Celsius
                    temp_celsius = (temp_info.CurrentTemperature / 10) - 273.15
                    zone_name = getattr(temp_info, 'InstanceName', f"ThermalZone_{temp_info.index}")
                    temperatures[zone_name] = round(temp_celsius, 1)
        except Exception as e:
            logger.error(f"Erro ao obter temperaturas via WMI: {str(e)}")
        
        return temperatures
    
    def _check_temperatures_linux(self):
        """Verifica as temperaturas no Linux usando sensors"""
        temperatures = {}
        
        try:
            sensors.init()
            for chip in sensors.iter_detected_chips():
                for feature in chip:
                    if feature.name.startswith('temp'):
                        label = feature.label or feature.name
                        temperatures[f"{chip.prefix}_{label}"] = feature.get_value()
            sensors.cleanup()
        except Exception as e:
            logger.error(f"Erro ao obter temperaturas via sensors: {str(e)}")
        
        return temperatures
    
    def _check_temperatures_alternative_windows(self):
        """Método alternativo para verificar temperaturas no Windows"""
        temperatures = {}
        
        try:
            # Tenta usar o comando 'wmic' para obter temperaturas
            output = subprocess.check_output("wmic /namespace:\\\\root\\wmi PATH MSAcpi_ThermalZoneTemperature get CurrentTemperature", shell=True)
            output_str = output.decode('utf-8', errors='ignore').strip()
            
            # Processa a saída
            lines = output_str.split('\n')
            if len(lines) > 1:
                for i, temp in enumerate(lines[1:], 1):
                    if temp.strip().isdigit():
                        # Convertendo de Kelvin * 10 para Celsius
                        temp_celsius = (int(temp.strip()) / 10) - 273.15
                        temperatures[f"ThermalZone_{i}"] = round(temp_celsius, 1)
        except Exception as e:
            logger.error(f"Erro ao obter temperaturas via WMIC: {str(e)}")
            
            # Tenta executar o comando 'core temp'
            try:
                output = subprocess.check_output("tasklist /fi \"imagename eq coretemp.exe\"", shell=True)
                if b"coretemp.exe" in output:
                    # CoreTemp está em execução, tenta ler os dados
                    # Isso exigiria interação com o CoreTemp, que pode ser complexa
                    pass
            except Exception:
                pass
        
        return temperatures
    
    def analyze_network(self):
        """Analisa a conectividade de rede"""
        logger.info("Analisando conectividade de rede")
        
        # Inicializa a estrutura de dados de rede
        self.results['network'] = {
            'interfaces': [],
            'bytes_sent': 0,
            'bytes_recv': 0,
            'packets_sent': 0,
            'packets_recv': 0,
            'errin': 0,
            'errout': 0,
            'internet_connected': False,
            'latency_ms': None,
            'dns_status': 'unknown',
            'gateway_status': 'unknown',
            'connection_quality': 'unknown',
            'active_connections': 0
        }
        
        # Analisa as interfaces de rede
        try:
            for interface, addresses in psutil.net_if_addrs().items():
                interface_info = {
                    'name': interface, 
                    'addresses': [],
                    'speed': 'unknown',
                    'is_up': True,  # Considera que está ativa por padrão
                    'mac_address': None
                }
                
                for address in addresses:
                    if address.family == socket.AF_INET:  # IPv4
                        interface_info['addresses'].append({
                            'ip': address.address,
                            'netmask': address.netmask,
                            'type': 'IPv4'
                        })
                    elif address.family == socket.AF_INET6:  # IPv6
                        interface_info['addresses'].append({
                            'ip': address.address,
                            'netmask': address.netmask,
                            'type': 'IPv6'
                        })
                    elif hasattr(socket, 'AF_PACKET') and address.family == socket.AF_PACKET:  # MAC address
                        interface_info['mac_address'] = address.address
                
                # Tenta obter status mais detalhados da interface
                try:
                    if_stats = psutil.net_if_stats().get(interface)
                    if if_stats:
                        interface_info['is_up'] = if_stats.isup
                        interface_info['speed'] = f"{if_stats.speed} Mbps" if if_stats.speed > 0 else "unknown"
                        interface_info['mtu'] = if_stats.mtu
                except Exception as e:
                    logger.warning(f"Erro ao obter estatísticas detalhadas da interface {interface}: {str(e)}")
                
                self.results['network']['interfaces'].append(interface_info)
        except Exception as e:
            logger.warning(f"Erro ao obter informações de interfaces de rede: {str(e)}")
        
        # Estatísticas de rede
        try:
            net_io = psutil.net_io_counters()
            self.results['network']['bytes_sent'] = net_io.bytes_sent
            self.results['network']['bytes_recv'] = net_io.bytes_recv
            self.results['network']['packets_sent'] = net_io.packets_sent
            self.results['network']['packets_recv'] = net_io.packets_recv
            self.results['network']['errin'] = net_io.errin
            self.results['network']['errout'] = net_io.errout
            
            # Calcula uso de banda aproximado (taxa de transferência)
            try:
                # Mede uso em dois momentos para calcular taxa
                time.sleep(0.5)  # Espera 0.5 segundo
                net_io2 = psutil.net_io_counters()
                down_speed = (net_io2.bytes_recv - net_io.bytes_recv) * 2  # Bytes por segundo
                up_speed = (net_io2.bytes_sent - net_io.bytes_sent) * 2  # Bytes por segundo
                
                self.results['network']['download_speed_bps'] = down_speed
                self.results['network']['upload_speed_bps'] = up_speed
                
                # Classifica qualidade com base na taxa
                if down_speed > 1024 * 1024:  # Mais de 1MB/s
                    self.results['network']['connection_quality'] = 'excellent'
                elif down_speed > 500 * 1024:  # Mais de 500KB/s
                    self.results['network']['connection_quality'] = 'good'
                elif down_speed > 100 * 1024:  # Mais de 100KB/s
                    self.results['network']['connection_quality'] = 'average'
                elif down_speed > 0:
                    self.results['network']['connection_quality'] = 'poor'
                else:
                    self.results['network']['connection_quality'] = 'inactive'
            except Exception as e:
                logger.warning(f"Erro ao calcular taxa de transferência: {str(e)}")
        except Exception as e:
            logger.warning(f"Erro ao obter estatísticas de rede: {str(e)}")
        
        # Verifica conexões ativas
        try:
            connections = psutil.net_connections()
            self.results['network']['active_connections'] = len(connections)
            
            # Identifica processos usando a rede (apenas uma amostra)
            network_processes = []
            for conn in connections[:10]:  # Limita para evitar processamento excessivo
                if conn.pid and conn.status == 'ESTABLISHED':
                    try:
                        proc = psutil.Process(conn.pid)
                        network_processes.append({
                            'pid': conn.pid,
                            'name': proc.name(),
                            'remote_ip': conn.raddr.ip if conn.raddr else None,
                            'remote_port': conn.raddr.port if conn.raddr else None,
                            'local_port': conn.laddr.port if conn.laddr else None
                        })
                    except Exception:
                        pass
                        
            if network_processes:
                self.results['network']['sample_processes'] = network_processes
        except Exception as e:
            logger.warning(f"Erro ao analisar conexões de rede: {str(e)}")
        
        # Teste de gateway
        try:
            import subprocess
            default_gateway = None
            
            if self.is_windows:
                try:
                    # Windows - usa ipconfig
                    output = subprocess.check_output("ipconfig", shell=True, text=True)
                    for line in output.split('\n'):
                        if "Default Gateway" in line or "Gateway Padrão" in line:
                            parts = line.split(':')
                            if len(parts) > 1 and parts[1].strip():
                                default_gateway = parts[1].strip()
                                break
                except Exception:
                    pass
            else:
                try:
                    # Linux - usa route
                    output = subprocess.check_output("ip route | grep default", shell=True, text=True)
                    parts = output.strip().split()
                    if len(parts) > 2:
                        default_gateway = parts[2]
                except Exception:
                    pass
            
            if default_gateway:
                self.results['network']['default_gateway'] = default_gateway
                
                # Testa ping para o gateway
                try:
                    if self.is_windows:
                        cmd = f"ping -n 4 {default_gateway}"
                    else:
                        cmd = f"ping -c 4 {default_gateway}"
                    
                    ping_output = subprocess.check_output(cmd, shell=True, text=True)
                    
                    # Extrai latência média
                    if "Average" in ping_output or "Media" in ping_output or "avg" in ping_output:
                        import re
                        
                        # Diferentes padrões para diferentes sistemas
                        latency_patterns = [
                            r"Average = (\d+)ms",  # Windows EN
                            r"Média = (\d+)ms",    # Windows PT
                            r"= [\d\.]+/(\d+\.\d+)/",  # Linux
                        ]
                        
                        for pattern in latency_patterns:
                            match = re.search(pattern, ping_output)
                            if match:
                                try:
                                    self.results['network']['latency_ms'] = float(match.group(1))
                                    self.results['network']['gateway_status'] = 'reachable'
                                    break
                                except ValueError:
                                    pass
                except Exception:
                    self.results['network']['gateway_status'] = 'unreachable'
            else:
                self.results['network']['gateway_status'] = 'not_found'
        except Exception as e:
            logger.warning(f"Erro ao testar gateway: {str(e)}")
        
        # Teste de DNS
        try:
            import socket
            dns_working = False
            test_domains = ['google.com', 'amazon.com', 'microsoft.com']
            
            for domain in test_domains:
                try:
                    socket.gethostbyname(domain)
                    dns_working = True
                    break
                except socket.gaierror:
                    continue
            
            self.results['network']['dns_status'] = 'working' if dns_working else 'failing'
            
            if not dns_working:
                self.problems.append({
                    'category': 'network',
                    'title': 'Resolução DNS não está funcionando',
                    'description': 'Não foi possível resolver nomes de domínio para endereços IP.',
                    'solution': 'Verifique as configurações DNS, tente usar o DNS 8.8.8.8 (Google) ou 1.1.1.1 (Cloudflare).',
                    'impact': 'medium'
                })
                self.score -= 10
        except Exception as e:
            logger.warning(f"Erro ao testar DNS: {str(e)}")
        
        # Teste de conectividade com a internet
        try:
            internet_connected = False
            test_sites = ['8.8.8.8', '1.1.1.1', 'google.com']
            for site in test_sites:
                try:
                    # Tenta abrir um socket TCP na porta 53 (DNS) ou 80 (HTTP)
                    for port in [53, 80]:
                        sock = socket.create_connection((site, port), timeout=2)
                        sock.close()
                        internet_connected = True
                        break
                    if internet_connected:
                        break
                except Exception:
                    continue
            
            self.results['network']['internet_connected'] = internet_connected
            
            if not internet_connected:
                self.problems.append({
                    'category': 'network',
                    'title': 'Sem conexão com a internet',
                    'description': 'Não foi possível conectar-se a sites populares.',
                    'solution': 'Verifique sua conexão de rede, reinicie o roteador ou contate seu provedor.',
                    'impact': 'high'
                })
                self.score -= 15
        except Exception as e:
            logger.warning(f"Erro ao testar conectividade com a internet: {str(e)}")
        
        # Detecta problemas em interfaces
        if not self.results['network']['interfaces']:
            self.problems.append({
                'category': 'network',
                'title': 'Nenhuma interface de rede detectada',
                'description': 'Não foi possível encontrar nenhuma interface de rede.',
                'solution': 'Verifique se os adaptadores de rede estão instalados corretamente.',
                'impact': 'high'
            })
            self.score -= 15
        else:
            # Verifica interfaces com problemas
            problem_interfaces = []
            for iface in self.results['network']['interfaces']:
                if not iface.get('is_up', False):
                    problem_interfaces.append(iface['name'])
            
            if problem_interfaces:
                self.problems.append({
                    'category': 'network',
                    'title': f"Interface(s) de rede desativada(s): {', '.join(problem_interfaces)}",
                    'description': 'Uma ou mais interfaces de rede estão desativadas.',
                    'solution': 'Verifique as configurações de rede e ative as interfaces necessárias.',
                    'impact': 'medium'
                })
                self.score -= 5
        
        # Verifica erros de rede
        if self.results['network'].get('errin', 0) > 1000 or self.results['network'].get('errout', 0) > 1000:
            self.problems.append({
                'category': 'network',
                'title': 'Erros frequentes na rede',
                'description': 'Foram detectados muitos erros de pacote na rede.',
                'solution': 'Verifique se há problemas com cabos, interferência Wi-Fi ou hardware de rede defeituoso.',
                'impact': 'medium'
            })
            self.score -= 5
        
        logger.info(f"Análise de rede concluída. Interfaces: {len(self.results['network'].get('interfaces', []))}, " +
                   f"Conectividade: {self.results['network'].get('internet_connected', False)}")
        
        return self.results['network']
    
    def generate_report(self):
        """
        Gera o relatório final do diagnóstico
        
        Returns:
            dict: Relatório completo com resultados, problemas e recomendações
        """
        # Ajusta a pontuação final para estar entre 0 e 100
        self.score = max(0, min(100, self.score))
        
        # Gera recomendações baseadas nos problemas encontrados
        recommendations = self.generate_recommendations()
        
        # Cria o relatório completo
        report = {
            'timestamp': datetime.now().isoformat(),
            'system': {
                'os': platform.system(),
                'os_version': platform.version(),
                'hostname': platform.node(),
                'machine': platform.machine(),
                'processor': platform.processor(),
                'python_version': platform.python_version()
            },
            'score': self.score,
            'results': self.results,
            'problems': sorted(self.problems, key=lambda x: 0 if x['impact'] == 'high' else 1 if x['impact'] == 'medium' else 2),
            'recommendations': recommendations
        }
        
        # Classificação do estado do sistema
        if self.score >= 90:
            report['system_status'] = "Excelente"
        elif self.score >= 80:
            report['system_status'] = "Bom"
        elif self.score >= 70:
            report['system_status'] = "Adequado"
        elif self.score >= 50:
            report['system_status'] = "Precisa de melhoria"
        else:
            report['system_status'] = "Crítico"
        
        logger.info(f"Relatório de diagnóstico gerado. Pontuação: {self.score}, Status: {report['system_status']}")
        
        return report
    
    def generate_recommendations(self):
        """
        Gera recomendações baseadas nos problemas encontrados
        
        Returns:
            list: Lista de recomendações ordenadas por prioridade
        """
        recommendations = []
        
        # Converte problemas em recomendações
        for problem in self.problems:
            recommendations.append({
                'title': 'Resolver: ' + problem['title'],
                'description': problem['solution'],
                'category': problem['category'],
                'impact': problem['impact']
            })
        
        # Adiciona recomendações gerais baseadas na pontuação
        if self.score < 50:
            recommendations.append({
                'title': 'Manutenção completa do sistema',
                'description': 'Seu sistema precisa de uma manutenção completa. Considere backup dos dados e reinstalação do sistema operacional se os outros reparos não forem suficientes.',
                'category': 'general',
                'impact': 'high'
            })
        elif self.score < 70:
            recommendations.append({
                'title': 'Otimização geral do sistema',
                'description': 'Seu sistema pode se beneficiar de uma otimização geral, incluindo limpeza de arquivos temporários, desfragmentação (para HDDs) e revisão de programas de inicialização.',
                'category': 'general',
                'impact': 'medium'
            })
        
        # Recomendações para hardware específico
        if 'cpu' in self.results:
            if self.results.get('cpu', {}).get('cores_physical', 0) < 4:
                recommendations.append({
                    'title': 'Atualização de processador',
                    'description': 'Seu processador está abaixo das especificações recomendadas para software moderno. Considere atualizar para um modelo com pelo menos 4 núcleos.',
                    'category': 'hardware',
                    'impact': 'medium'
                })
        
        if 'memory' in self.results:
            total_ram_gb = self.results.get('memory', {}).get('total', 0) / 1024  # GB
            if total_ram_gb < 8:
                recommendations.append({
                    'title': 'Atualização de memória RAM',
                    'description': f'Seu sistema tem {total_ram_gb:.1f}GB de RAM. Para melhor desempenho, recomendamos atualizar para pelo menos 8GB de RAM.',
                    'category': 'hardware',
                    'impact': 'high' if total_ram_gb < 4 else 'medium'
                })
        
        # Ordena as recomendações por impacto
        impact_priority = {'high': 0, 'medium': 1, 'low': 2}
        recommendations.sort(key=lambda x: impact_priority.get(x['impact'], 3))
        
        return recommendations

    def get_system_metrics(self, user_id: str = None) -> dict:
        """Retorna métricas simuladas do sistema para compatibilidade com API e testes."""
        return {
            'cpu': 50,
            'memory': 60,
            'disk': 70,
            'network': 80
        } 