"""
Módulo de modelos de dados para a aplicação TechCare.
""" 