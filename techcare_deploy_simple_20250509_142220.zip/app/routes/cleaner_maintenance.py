from flask import render_template
from flask_login import login_required, current_user
from app.services.cleaner_service import CleanerService
from .cleaner import cleaner

@cleaner.route('/disk_cleanup')
@login_required
def disk_cleanup():
    cleaner_service = CleanerService()
    return render_template('cleaner/disk_cleanup.html', title="Limpeza de Disco")

@cleaner.route('/temp_cleanup')
@login_required
def temp_cleanup():
    cleaner_service = CleanerService()
    return render_template('cleaner/temp_cleanup.html', title="Limpeza de Temporários")

@cleaner.route('/maintenance_plans')
@login_required
def maintenance_plans():
    cleaner_service = CleanerService()
    return render_template('cleaner/maintenance_plans.html', title="Manutenção Programada") 