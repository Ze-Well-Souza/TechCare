# Este arquivo está vazio intencionalmente para marcar o diretório como um pacote Python
from flask import Blueprint, Flask
from app.routes.main import main
from app.routes.auth import auth
from app.routes.diagnostic import diagnostic
from app.routes.diagnostic_analysis import diagnostic_analysis
from app.routes.diagnostic_overview import diagnostic_overview
from app.routes.repair import repair
from app.routes.drivers import drivers
from app.routes.cleaner import cleaner
from app.routes.cleaner_analysis import cleaner_analysis
from app.routes.cleaner_cleaning import cleaner_cleaning
from app.routes.cleaner_maintenance import cleaner_maintenance
from app.routes.api import api
from app.routes.diagnostic_visualization import visualization

def register_blueprints(app: Flask) -> None:
    """
    Registra todos os blueprints na aplicação Flask.
    
    Args:
        app: Instância da aplicação Flask
    """
    # Blueprint principal
    app.register_blueprint(main, url_prefix='/')
    
    # Blueprint de autenticação
    app.register_blueprint(auth, url_prefix='/auth')
    
    # Blueprints de diagnóstico
    app.register_blueprint(diagnostic, url_prefix='/diagnostic')
    app.register_blueprint(diagnostic_analysis, url_prefix='/diagnostic/analysis')
    app.register_blueprint(diagnostic_overview, url_prefix='/diagnostic/overview')
    app.register_blueprint(visualization, url_prefix='/diagnostic/visualization')
    
    # Blueprint de reparo
    app.register_blueprint(repair, url_prefix='/repair')
    
    # Blueprint de drivers
    app.register_blueprint(drivers, url_prefix='/drivers')
    
    # Blueprints de limpeza
    app.register_blueprint(cleaner, url_prefix='/cleaner')
    app.register_blueprint(cleaner_analysis, url_prefix='/cleaner/analysis')
    app.register_blueprint(cleaner_cleaning, url_prefix='/cleaner/cleaning')
    app.register_blueprint(cleaner_maintenance, url_prefix='/cleaner/maintenance')
    
    # Blueprint da API
    app.register_blueprint(api, url_prefix='/api')
    
    # Registra API blueprints
    register_api_blueprints(app)
    
    return app

def register_api_blueprints(app):
    """Registra blueprints para a API"""
    from app.routes.api import api
    
    app.register_blueprint(api, url_prefix='/api')
    
    return app 