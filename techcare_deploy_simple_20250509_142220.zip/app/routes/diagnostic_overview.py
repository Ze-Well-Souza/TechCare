from flask import render_template, request, jsonify
from flask_login import login_required, current_user
from app.models.diagnostic import Diagnostic
from app import db
from .diagnostic import diagnostic
import json

@diagnostic.route('/')
@login_required
def index():
    """Rota da página de diagnóstico"""
    return render_template('diagnostic/index.html')

@diagnostic.route('/results/<int:diagnostic_id>')
@login_required
def view_results(diagnostic_id):
    try:
        diagnostic_model = db.session.get(Diagnostic, diagnostic_id)
        if not diagnostic_model:
            return render_template('errors/404.html', message="Diagnóstico não encontrado"), 404
        if diagnostic_model.user_id != current_user.id and not current_user.is_admin() and not current_user.is_technician():
            return render_template('errors/403.html', message="Você não tem permissão para acessar este diagnóstico"), 403
        results = {
            'id': diagnostic_model.id,
            'name': diagnostic_model.name,
            'date': diagnostic_model.date.strftime('%d/%m/%Y %H:%M'),
            'score': diagnostic_model.score,
            'status': diagnostic_model.status,
            'cpu': diagnostic_model.get_cpu_results(),
            'memory': diagnostic_model.get_memory_results(),
            'disk': diagnostic_model.get_disk_results(),
            'startup': diagnostic_model.get_startup_results(),
            'drivers': diagnostic_model.get_driver_results(),
            'security': diagnostic_model.get_security_results(),
            'network': diagnostic_model.get_network_results(),
            'recommendations': json.loads(diagnostic_model.recommendations) if diagnostic_model.recommendations else [],
            'problems': json.loads(diagnostic_model.notes) if diagnostic_model.notes else []
        }
        response_format = request.args.get('format', 'html')
        if response_format == 'json':
            return jsonify(results)
        else:
            return render_template('diagnostic/results.html', results=results)
    except Exception as e:
        return render_template('errors/500.html', message=str(e)), 500

@diagnostic.route('/history')
@login_required
def history():
    if current_user.is_admin():
        diagnostics = Diagnostic.query.order_by(Diagnostic.date.desc()).all()
    else:
        diagnostics = Diagnostic.query.filter_by(user_id=current_user.id).order_by(Diagnostic.date.desc()).all()
    response_format = request.args.get('format', 'html')
    if response_format == 'json':
        return jsonify([{
            'id': diag.id,
            'name': diag.name,
            'date': diag.date.strftime('%d/%m/%Y %H:%M'),
            'score': diag.score,
            'status': diag.status
        } for diag in diagnostics])
    else:
        return render_template('diagnostic/history.html', diagnostics=diagnostics) 