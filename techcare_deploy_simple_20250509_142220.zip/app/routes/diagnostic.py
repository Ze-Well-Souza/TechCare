from flask import Blueprint

diagnostic = Blueprint('diagnostic', __name__, url_prefix='/diagnostic')

# Importa submódulos de rotas
from . import diagnostic_overview
from . import diagnostic_analysis
from . import diagnostic_api 