from flask import request, jsonify, flash, redirect, url_for, render_template
from flask_login import login_required, current_user
import platform
from app.services.cleaner_service import CleanerService
from .cleaner import cleaner

@cleaner.route('/cleaner/clean-temp', methods=['POST'])
@login_required
def clean_temp_files():
    try:
        cleaner_service = CleanerService()
        result = cleaner_service.clean_temp_files()
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@cleaner.route('/cleaner/clean-browser', methods=['POST'])
@login_required
def clean_browser_cache():
    try:
        browsers = request.json.get('browsers', None)
        cleaner_service = CleanerService()
        result = cleaner_service.clean_browser_cache(browsers)
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@cleaner.route('/cleaner/clean-registry', methods=['POST'])
@login_required
def clean_registry():
    try:
        cleaner_service = CleanerService()
        result = cleaner_service.clean_registry()
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@cleaner.route('/cleaner/verify-disk', methods=['POST'])
@login_required
def verify_disk():
    try:
        cleaner_service = CleanerService()
        result = cleaner_service.verify_disk()
        return jsonify(result)
    except Exception as e:
        return jsonify({'success': False, 'error': str(e)}), 500

@cleaner.route('/execute_cleanup', methods=['POST'])
@login_required
def execute_cleanup():
    options = request.form.getlist('cleanup_options')
    cleaner_service = CleanerService()
    results = cleaner_service.clean_system(options)
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify(results)
    flash('Limpeza concluída com sucesso!', 'success')
    return redirect(url_for('cleaner.disk_cleanup')) 