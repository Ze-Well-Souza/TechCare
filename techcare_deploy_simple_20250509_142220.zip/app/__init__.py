from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager
import datetime
import os
from pathlib import Path

from config import config

# Inicialização das extensões
db = SQLAlchemy()
login_manager = LoginManager()
login_manager.login_view = 'auth.login'


def create_app(config_name='default'):
    """
    Função factory para criar a aplicação Flask
    
    Args:
        config_name: Nome da configuração a ser usada (default, development, testing, production)
        
    Returns:
        Aplicação Flask configurada
    """
    app = Flask(__name__)
    app.config.from_object(config[config_name])
    config[config_name].init_app(app)
    
    # Inicialização das extensões com a aplicação
    db.init_app(app)
    login_manager.init_app(app)
    
    # Configuração dos serviços e repositórios
    setup_services(app)
    
    # Registro dos blueprints
    from app.routes.main import main as main_blueprint
    app.register_blueprint(main_blueprint)
    
    from app.routes.diagnostic import diagnostic as diagnostic_blueprint
    app.register_blueprint(diagnostic_blueprint, url_prefix='/diagnostic')
    
    from app.routes.auth import auth as auth_blueprint
    app.register_blueprint(auth_blueprint)
    
    from app.routes.repair import repair as repair_blueprint
    app.register_blueprint(repair_blueprint, url_prefix='/repair')
    
    from app.routes.drivers import drivers as drivers_blueprint
    app.register_blueprint(drivers_blueprint, url_prefix='/drivers')
    
    from app.routes.cleaner import cleaner as cleaner_blueprint
    app.register_blueprint(cleaner_blueprint, url_prefix='/cleaner')
    
    from app.routes.api import api as api_blueprint
    app.register_blueprint(api_blueprint)
    
    # Criar todas as tabelas do banco de dados
    with app.app_context():
        db.create_all()
    
    # Adiciona variáveis de contexto para todos os templates
    @app.context_processor
    def inject_now():
        return {'now': datetime.datetime.now()}
    
    # Handlers globais de erro
    @app.errorhandler(404)
    def page_not_found(e):
        return render_template('errors/404.html', message=str(e)), 404

    @app.errorhandler(500)
    def internal_server_error(e):
        return render_template('errors/500.html', message=str(e)), 500

    @app.errorhandler(403)
    def forbidden(e):
        return render_template('errors/403.html', message=str(e)), 403

    return app

def setup_services(app):
    """
    Configura os serviços e repositórios da aplicação
    
    Args:
        app: Aplicação Flask
    """
    # Importações aqui para evitar circular imports
    from app.services.service_factory import ServiceFactory
    from app.services.diagnostic_repository import DiagnosticRepository
    
    # Configura o caminho para armazenamento de diagnósticos
    diagnostics_path = app.config.get('DIAGNOSTICS_STORAGE_PATH', os.path.join(app.instance_path, 'diagnostics'))
    
    # Cria o diretório se não existir
    os.makedirs(diagnostics_path, exist_ok=True)
    
    # Cria e registra o repositório de diagnósticos
    diagnostic_repository = DiagnosticRepository(diagnostics_path)
    
    # Registra o repositório como dependência para o serviço de diagnóstico
    ServiceFactory.register_dependency(
        'DiagnosticService', 
        'diagnostic_repository', 
        diagnostic_repository
    ) 